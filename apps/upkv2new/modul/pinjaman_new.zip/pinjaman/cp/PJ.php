<?php session_start();
include "../../../inc/inc.koneksi.php";
include "../../../inc/terbilang.php";
include "../../../inc/fungsi_indotgl.php";
include "../../../inc/fungsi_pinjaman.php";

?>

<style type="text/css">
<!--
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;  }
.style9 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; }
.top	{border-top: 1px solid #000000; }
.bottom	{border-bottom: 1px solid #000000; }
.left	{border-left: 1px solid #000000; }
.right	{border-right: 1px solid #000000; }
.style26 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style27 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
-->
</style>
<body onLoad="window.print()">

     	    <?php
		$rcp=$_GET['rcp'];
		$view=mysql_query("SELECT * FROM
							kabupaten b, kecamatan kc, desa d, sebutan_desa sd, kelompok_$_SESSION[kd_kab] k, jenis_produk_pinjaman jpp, jenis_usaha ju, jenis_kegiatan jk, tingkat_kelompok tk, jenis_jasa jj,
							fungsi_kelompok fgs, users u, sistem_angsuran sa, pinjaman_kelompok_$_SESSION[kd_kab] pk
							WHERE
							b.id=kc.kd_kab AND kc.id=k.lokasi AND d.id=k.desa AND d.sebutan=sd.id AND pk.id_kel=k.id AND jpp.id=pk.jenis_pp AND ju.id=k.jenis_usaha AND 			
							jk.id=k.jenis_kegiatan AND tk.id=k.tingkat_kelompok AND fgs.id=k.fungsi_kelompok AND u.id=k.id_user AND jj.id=pk.jenis_jasa AND
							sa.id=pk.sistem_angsuran AND pk.id='$rcp'");
		$no=0;
		while($row=mysql_fetch_array($view)){
		
											$id_pinj			=$row['id'];
											$id_kel				=$row['id_kel'];
											$jenis_pp			=$row['jenis_pp'];
											$tgl_proposal		=$row['tgl_proposal'];
											$proposal			=$row['proposal'];
											$tgl_verifikasi		=$row['tgl_verifikasi'];
											$nama_bkad_sort     =$row['nama_bkad_sort'];
											
											$alokasi			=$row['alokasi'];
											$tgl_cair			=$row['tgl_cair'];
											$tanggal			 = substr($tgl_cair,8,2);
											$bulan  			 = getBulan(substr($tgl_cair,5,2));
											$tahun  			 = substr($tgl_cair,0,4);
											$pros_jasa			=$row['pros_jasa'];
											$jenis_jasa			=$row['nama_jj'];
											$jangka				=$row['jangka'];
											$sistem_angsuran	=$row['nama_sistem'];
											$lu					=$row['lu'];
											$status				=$row['status'];
											$user_id			=$row['user_id'];
											$dus				=mysql_fetch_array(mysql_query("SELECT * FROM users u, level l WHERE u.level=l.id AND u.id='$user_id' "));
											$nama_user			=$dus['namadepan']. " " .$dus['namabelakang']." (".$dus['nama_level'].")";
											
											$sebutan_desa		=mysql_fetch_array(mysql_query("SELECT * FROM desa d, sebutan_desa sd WHERE kd_desa=$row[kd_desa] AND sd.id=d.sebutan"));
											$lokasi				=$row['lokasi'];
											$nama_kec			=$row['nama_kec'];
											$ttd_saksi			=$row['ttd_saksi'];
											$nama_desa			=$row['nama_desa'];
											$kd_kelompok		=$row['kd_kelompok'];
											$nama_kelompok		=$row['nama_kelompok'];
											$alamat_kelompok	=$row['alamat_kelompok'];
											$telpon				=$row['telpon'];
											$tgl_berdiri		=$row['tgl_berdiri'];
											$nama_jpp			=$row['nama_jpp'];
											$jenis_usaha		=$row['nama_ju'];
											$jenis_kegiatan		=$row['nama_jk'];
											$tingkat_kelompok	=$row['nama_tk'];
											$fungsi_kelompok	=$row['nama_fgs'];
											$ketua				=$row['ketua'];
											$sekretaris			=$row['sekretaris'];
											$bendahara			=$row['bendahara'];
											$lo					=$row['lo'];
											$uname				=$row['uname'];
											$kades				=$row['kades'];
											$nip				=$row['nip'];
											$pass				=$row['pass'];
											$id_user			=$row['namadepan']. " " .$row['namabelakang'];
											$tgl_now			=date('Y-m-d');

	if($status=="P") {$dok="Proposal"; $judul="DAFTAR USULAN"; $tanggal=$tgl_proposal; $tempat="Diusulkan di"; $lembar="Lamp-4";}
	else if ($status=="V") {$dok="Verified"; $judul="DAFTAR USULAN"; $tanggal=$tgl_verifikasi; $tempat="Diusulkan di"; $lembar="Lamp-4";}
    else {$dok="Pencairan"; $judul="TANDA TERIMA"; $tanggal=$tgl_cair; $tempat="Dicairkan di"; $lembar="Lembar-1";}

$ketuaupk			=mysql_fetch_array(mysql_query("SELECT * FROM users WHERE lokasi='$lokasi' AND level='1' AND jabatan='1' AND sejak<='$tanggal' "));
$ketuabkad			=mysql_fetch_array(mysql_query("SELECT * FROM users WHERE lokasi='$lokasi' AND level='2' AND jabatan='1' AND sejak<='$tanggal' "));
											

				
			?>
<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
       <tr>
      <td height="20" colspan="2" class="bottom" width="5%">
        <?php
        $logo=$row['logo'];
          if (empty($logo)) {
            echo "<img class='' alt='...' src='../../../images/upk.png' style='float:left; width:50; margin-right:5px;'>";
            }else{
            echo "<img class='' alt='...' src='../../../images/logo/$logo' style='float:left; width:50; margin-right:5px;'>";
            }
            echo "</td>";
            echo "<td class='bottom'>";
                      
      $nomor_bh =$row ['nomor_bh'];
      if (empty($nomor_bh)) {$bh="";}else{$bh="Badan Hukum No.$nomor_bh<br>";}
    
      echo "<div class='style9'>".strtoupper("<b>$row[nama_lembaga_long]<br>KECAMATAN $row[nama_kec] KABUPATEN $row[nama_kab]</b>")."<br>$bh $row[alamat_kec] Telp. $row[telpon_kec] </div>"; 
      ?>
      </td>
      <td height="20" colspan="2" class="bottom"><div align="right" class="style9">Dokumen <?php echo $dok;?><br>
      Loan ID. <?php echo $id_pinj;?>
       <?php echo $lembar;?> </div></td>
    </tr> 
</table>
<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
      <tr>
        <td height="20" colspan="4" class="bottom"><p align="center" class="style6">
		SURAT PERSETUJUAN PENJAMIN<br>
		<span class="fw-semi-bold">CALON PEMINJAM</p></td>
      </tr>
      
      
      <tr>
        <td height="25" colspan="4" class="style9">&nbsp;</td>
      </tr>
      <tr>
        <td width="191" height="24" class="style9">Nama Kelompok</td>
        <td width="360" height="24"><span class="style9">:</span><span class="style27"> <?php echo $nama_kelompok;?></span></td>
        <td width="153" height="24" class="style9">Alokasi Pinjaman</td>
        <td width="331" height="24"><span class="style9">:</span><span class="style27"> Rp. <?php echo number_format($alokasi);?>,-</span></td>
      </tr>
      <tr>
        <td height="24" class="style9">Alamat</td>
        <td height="24"><span class="style9">:</span><span class="style27"> <?php echo $alamat;?> <?php echo $nama_desa;?></span></td>
        <td height="24" class="style9"> Sistem Angsuran </td>
        <td height="24"><span class="style9">:</span><span class="style27"> <?php echo $sistem_angsuran;?></span></td>
      </tr>
      <tr>
        <td height="25" class="style9">Tanggal <?php echo $dok;?></td>
        <td height="25"><span class="style9">:</span><span class="style27"> <?php echo tgl_indo($tanggal); ?></span></td>
        <td height="25" class="style9">Prosentase Jasa </td>
        <td height="25"><span class="style9">:</span><span class="style27"> <?php echo "$pros_jasa % $jenis_jasa/bulan";?></span></td>
      </tr>
      <tr>
        <td height="25" class="style9">Nomor SPK. </td>
        <td height="25" class="style9">: <span class="style27"> <?php echo $row['spk_no'];?></span></td>
      </tr>
      <tr>
        <td height="25" class="style9">&nbsp;</td>
        <td height="25" class="style27">&nbsp;</td>
        <td height="25" class="style9">&nbsp;</td>
        <td height="25" class="style27">&nbsp;</td>
      </tr>
</table>
	  <table width="97%" border="0" align="center" cellpadding="3" cellspacing="0" class="top bottom left right">
      <tr>	  
          <th width="3%" height="34" class="style9 bottom top left">No</th>
			  <th width="15%" class="style9 left bottom top" >N I K Peminjam</th>
              <th width="15%" class="style9 left bottom top">Nama Peminjam</th>
			<th width="15%" class="style9 left bottom top" >N I K Penjamin</th>
              <th width="15%" class="style9 left bottom top">Nama Penjamin</th>
              <th width="15%" class="style9 left bottom top">Tanda Tangan Penjamin</th>
			  <th width="15%" class="style9 left bottom top right">Keterangan</th>
			  
        </tr>      
		
<?php 	
		$angg=mysql_query("select * from pinjaman_anggota_$_SESSION[kd_kab] where id_pinkel='$id_pinj'");  /* query hitung jumlah anggota */
		$jml_anggota=mysql_num_rows($angg);
		$no=0;
		while($data=mysql_fetch_array($angg)){
		$nia=$data['nia'];
		$alok_anggota=$data['alokasi'];
		
		$anggota=mysql_query("select * from anggota_$_SESSION[kd_kab] a, usaha u WHERE a.id='$nia' AND a.usaha = u.id  order by namadepan ASC");  /* untuk memunculkan ke tabel tampil */	
		while($row6=mysql_fetch_array($anggota)){
						  
						  $nama_anggota		=$row6['namadepan'];
						  $penjamin			=$row6['penjamin'];
						  $id_anggota		=$row6['nik'];
						  $id_penjamin		=$row6['nik_penjamin'];
						  $jenis_kelamin	=$row6['jk'];
						  $usaha			=$row6['nama_usaha'];  
						  $tempat_lahir		=$row6['tempat_lahir'];
						  $tgl_lahir		=$row6['tgl_lahir'];
						  $alamat_anggota	=$row6['alamat'];
						  $nomor_hp			=$row6['hp'];
						   ?>
		
		
		<!-- Menampilkan data pada tabel -->
            <tr>
              <td height="33" class="style9 top left"><div align="center" ><?php echo $no=$no+1;?></div></td>
              <td class="style9 left top"><div align="center"><?php echo $id_anggota;?></div></td>
              <td class="style9 left top"><?php echo $nama_anggota; ?></td>
              <td class="style9 left top"><?php echo $id_penjamin;?></td>
              <td class="style9 left top"><span class="style9"><?php echo $penjamin?></span></td>
              <td class="style9 left top"><?php echo $no;?>.</td>
			  <td class="style9 left top right">&nbsp; </td>
            </tr>
  <?php 
  $sum_anggota=$sum_anggota+$alok_anggota;
  } } ?>
		<!-- Menampilkan Jumlah Total pada tabel -->
</table>
<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
      <tr>
        <td  colspan="3" class="style9 top">&nbsp;</td>
      </tr>
      <tr>
        <td  colspan="3" class="style9">Dengan ini menyatakan setuju atas pinjaman yang diajukan oleh <b>Peminjam</b> kepada <b> <?php echo "$row[nama_lembaga_long] Kecamatan $row[nama_kec]"?></b> dan bersedia menanggung / melunasi pinjaman jika terjadi tunggakan angsuran yang sudah jatuh tempo pada pinjaman <b>Peminjam</b> tersebut diatas.</td>
      </tr>
      <table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
	  <tr><td colspan="4" class="style9" align="right"><p>&nbsp;</p> <p><?php echo "$nama_kec , ".tgl_indo($tgl_proposal);?></p><p>&nbsp;</p></td></tr>
      <tr>
	    <td height="24" colspan="-1" class="style9"><p align="center">Ketua</p><!----------ketua------------->
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p>
		<p align="center"><b><?php echo "$ketua"?></b></p>
		</td>
	    <td height="24" colspan="-1" class="style9"><p align="center">Sekertaris</p><!----------sekret------------->
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p>
		<p align="center"><b><?php echo "$sekretaris"?></b></p>
		</td>
        <td class="style9"><p align="center">Bendahara</p><!------------bendahara----------->
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p>
		<p align="center"><b><?php echo "$bendahara"?></b></p>
		</td>
	  </tr>
	  <tr><td>&nbsp;<br>&nbsp;<br></td></tr>
	  <!------------------------------------------------------------------------------------->
	  <?php if($_SESSION['lokasi']==279 OR $_SESSION['lokasi']==1){?>
      <tr>
        <td height="24" colspan="-1" class="style9"><p align="center">mengetahui,</p>
        <p align="center"> <?php echo "$sebutan_desa[sebutan_kades] $nama_desa";?></p>
        <p>&nbsp;</p>
		<p>&nbsp;</p>
		<p align="center"><b><?php echo "$kades"?></b><br>NIP. <?php echo "$nip"?></p>
		</td>
	    <td height="24" colspan="-1" class="style9"><p align="center"></p>
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p>
		<p align="center"><b></b></p>
		</td>
        <p>&nbsp;</p>
        <td class="style9"><p align="center">Dukuh</p>
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p>
		<p align="center"><b>_____________________</b></p>
		</td>
  </tr>
	  <?php }else{?>
  <!--------------------------------------------------------------------------------------------->
  <tr>
        <td class="style26" colspan="3"><div align="right" class="style9">
		
		 <p>&nbsp;</p>
         
<center>		
		Mengetahui,<br>
		  <?php echo "$sebutan_desa[sebutan_kades] $nama_desa";?>
		  </center>
        </div></td>
      </tr>	
	<tr>
	    <td height="24" width="30%" class="style9"><p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p>&nbsp;</p><p>&nbsp;</p></td>
        <td class="style9" width="30%"><p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p align="center"><b><?php echo "$kades"?></b><br>NIP. <?php echo "$nip"?></p></td><td width="30%"></dh>
  </tr>
      <!----------------------------------------------------------------------------------------->
	  <?php }?>
</table>

</table>
<title>Surat Persetujuan <?php echo $kd_kelompok;?>-<?php echo $id_pinj;?> Kelompok <?php echo $nama_kelompok;?> Desa <?php echo $nama_desa;?></title>
<?php } ?>        
</body>
