<?php session_start();
include "../../../inc/inc.koneksi.php";
include "../../../inc/terbilang.php";
include "../../../inc/fungsi_indotgl.php";
include "../../../inc/fungsi_keuangan.php";
$table_rekening		="rekening_".$_SESSION['lokasi'];
$lokasi				=$_SESSION['lokasi'];

$report				=$_POST['report'];
if (empty($report)) {
	$idf				=$_GET['idf'];
	$d					=$_GET['d'];
	$m					=$_GET['m'];
	$y					=$_GET['y'];
}else{
	$idf				=substr($_POST['sub_report'],3);
	$d					=$_POST['d'];
	$m					=$_POST['m'];
	$y					=$_POST['y'];
}


$tgl				="$y-$m-$d";
$mll				=$m-1; if($ml<10) {$ml="0$mll"; }else{ $ml=$mll; }


	 if($d=$d){$laporan="Harian"; $jenis="Tanggal"; $tgl_kondisi="$y-$m-$d"; $tgl_kondisibulanlalu="$y-$ml-$d"; $judulL="Kemaren"; $judulC="Hari Ini";  }
else if($m=$m){$laporan="Bulanan"; $jenis="Bulan"; $tgl_kondisi=date("Y-m-t", strtotime("$y-$m-01")); $tgl_kondisibulanlalu=date("Y-m-t", strtotime("$y-$ml-01")); $judulL="Bulan Lalu"; $judulC="Bulan Ini";}
else if($y=$y){$laporan="Tahunan"; $jenis="Tahun"; $tgl_kondisi="$y-12-31"; $tgl_kondisibulanlalu="$y-12-31"; $judulL="Tahun Lalu"; $judulC="Tahun Ini"; }
else{$laporan="Global";}

$row=mysql_fetch_array(mysql_query("SELECT * FROM kabupaten k, kecamatan c where k.id=c.kd_kab AND c.id='$lokasi' "));
$u=mysql_fetch_array(mysql_query("SELECT * FROM users where id='$_SESSION[id]' "));
?>

<style type="text/css">
<!--
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;  }
.style9 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; }
.style10 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px; }
.top	{border-top: 1px solid #000000; }
.bottom	{border-bottom: 1px solid #000000; }
.left	{border-left: 1px solid #000000; }
.right	{border-right: 1px solid #000000; }
.all	{border: 1px solid #000000; }
.style26 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style27 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
.align-justify {text-align:justify; }
.align-center {text-align:center; }
.align-right {text-align:right; }
.pull-right {
  float: right;
  margin-left:120px;
}
-->
</style>
<body onLoad="window.print()">
<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
       <tr>
			<td height="20" colspan="2" class="bottom" width="5%">
				<div class="style9 text-align-left"><?php
                    $logo=$row['logo'];
                      if (empty($logo)) {
                        echo "<img class='' alt='...' src='../../../images/upk.png' style='float:left; width:50; margin-right:5px;'>";
                        }else{
                        echo "<img class='' alt='...' src='../../../images/logo/$logo' style='float:left; width:50; margin-right:5px;'>";
                        }
                 echo"</td>
                 	  <td class='bottom'>
                 ";
                                  
                  $nomor_bh =$row ['nomor_bh'];
                  if (empty($nomor_bh)) {$bh="";}else{$bh="Badan Hukum No.$nomor_bh<br>";}
                
                  echo "<div class='style9'>".strtoupper("<b>$row[nama_lembaga_long]<br>KECAMATAN $row[nama_kec] KABUPATEN $row[nama_kab]</b>")."<br>$bh $row[alamat_kec] Telp. $row[telpon_kec] </div>"; 
                  ?>      
				</div>
			</td>
			<td height="20" colspan="2" class="bottom"><div align="right" class="style9"></div></td>
	  </tr> 
</table>
		<table width="96%" border="0" align="center" cellpadding="3" cellspacing="0" class="style9">
            <tr>
				<td height="20" colspan="2" class="style6 bottom align-center"><br>N E R A C A <br><?php echo strtoupper("$jenis ".tgl_indo($tgl));?></td>
			</tr>
			<tr>
			  <th height="30" class="left top bottom">AKTIVA</th>
			  <th class="all">PASSIVA</th>
		    </tr>
			<tr>
			  <td class="left top bottom" width="50%">
					<table width='100%' cellpadding="0" cellspacing="0" class="style9">
						<?php
						$view=mysql_query("select * from rekening_riil WHERE posisi='1' ORDER by id ASC ");
						while($row=mysql_fetch_array($view)){
						$data=mysql_query("SELECT * FROM jenis_buku WHERE kd_jr='$row[kd_rr]' AND kecuali NOT LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi],%' AND lokasi='0' OR kd_jr='$row[kd_rr]' AND lokasi LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi],%' ORDER by kd_jb ASC ");
						echo "
						<tr>
							<td><strong>$row[nama_rr]</strong><br> ";
							while($r=mysql_fetch_array($data)){

							$saldo_aktiva=saldo("$tgl_kondisi-".$r['kd_jb']);
							if($r['kd_jb']=='141' AND $_SESSION['lokasi']==176){
						    $nilaibuku="Nilai Buku";
							$saldo_debit=saldodebit("$tgl_kondisi-".$r['kd_jb']);
							$saldo_kredit=saldokredit("$tgl_kondisi-".$r['kd_jb']); ?>
							    <table width='100%' class='style9'>
								<tr>
									<td width='60%'>141.01 Perolehan Biaya Dibayar Dimuka</td>
									<td width='30%' class='align-right'><?php echo number_format_koma($saldo_debit); ?></td>
									<td width='10%'>&nbsp;</td>
								</tr>
								<tr>
									<td width='60%'>141.02 Akumulasi Amortisasi</td>
									<td width='30%' class='align-right'><?php echo number_format_koma($saldo_kredit); ?></td>
									<td width='10%'>&nbsp;</td>
								</tr>
							</table>
							<?php
							}
							if($r['kd_jb']=='151' AND $_SESSION['lokasi']==176){
						    $nilaibuku="Nilai Buku";
							$saldo_debit=saldodebit("$tgl_kondisi-".$r['kd_jb']);
							$saldo_kredit=saldokredit("$tgl_kondisi-".$r['kd_jb']);  ?>
							    <table width='100%' class='style9'>
								<tr>
									<td width='60%'>151.01 Prolehan Inventaris</td>
									<td width='30%' class='align-right'><?php echo number_format_koma($saldo_debit); ?></td>
									<td width='10%'>&nbsp;</td>
								</tr>
								<tr>
									<td width='60%'>151.02 Penyusutan dan Penghapusan Inventaris</td>
									<td width='30%' class='align-right'><?php echo number_format_koma($saldo_kredit); ?></td>
									<td width='10%'>&nbsp;</td>
								</tr>
							</table>
							<?php
							}
							echo	"
							<table width='100%' class='style9'>
								<tr>
									<td width='70%'>$r[kd_jb]. $nilaibuku $r[nama_jb]</td>
									<td width='30%' class='align-right'>".number_format_koma($saldo_aktiva)."</td>
								</tr>
							</table>
							";
																																	
							$aktiva=$aktiva+$saldo_aktiva;
							}
							echo "
							</td>
						</tr> 
						";					
						}
						?>
					</table>
			  
			  </td>
			  <td class="all"  width="50%">
					<table width='100%' cellpadding="0" cellspacing="0" class="style9">
					<?php
						$view=mysql_query("select * from rekening_riil WHERE posisi='2' OR posisi='3' ORDER by id ASC ");
						while($row=mysql_fetch_array($view)){
						$data=mysql_query("SELECT * FROM jenis_buku WHERE kd_jr='$row[kd_rr]' AND kecuali NOT LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi],%' AND lokasi='0' OR kd_jr='$row[kd_rr]' AND lokasi LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi],%' ORDER by kd_jb ASC ");
						echo "
						<tr>
							<td><strong>$row[nama_rr]</strong><br> ";
							while($r=mysql_fetch_array($data)){

							$saldo_passiva=saldo("$tgl_kondisi-".$r['kd_jb'])*-1;
																																		
							echo	"
							<table width='100%' class='style9'>
								<tr>
									<td width='70%'>$r[kd_jb]. $r[nama_jb]</td>
									<td width='30%' class='align-right'>".number_format_koma($saldo_passiva)."</td>
								</tr>
							</table>
							";
																																	
							$passiva=$passiva+$saldo_passiva;
							}
							echo "
							</td>
						</tr> 
						";					
						}
						?>
						<tr><td><strong>Surplus/Devisit</strong><span class="pull-right">
						<?php echo number_format_koma(surplus($tgl_kondisi));?></span></td></tr>
					</table>
			  </td>
		    </tr>		
		    <tr>
			  <th height="30" class="left top bottom"><span class='pull-right'><?php echo number_format_koma($aktiva);?></span></th>
			  <th class="all"><span class='pull-right'><?php echo number_format_koma(surplus($tgl_kondisi)+$passiva);?></span></th>
		    </tr>
			
			<tr>
			  <td class="top bottom">&nbsp;</td>
			  <th class="top">&nbsp;</td>
		    </tr>
			<?php
			$ma=modalawal("$tgl_kondisi");
			$ap=asetproduktif("$tgl_kondisi");
			if($_SESSION['kd_kab']=='23'){ // Khusus Kabupaten Blitar
			$pd=$ap-$ma;
			$pr=@($pd/$ma*100);
			} else {
			$pd=$aktiva-$ma;
			$pr=@($pd/$ma*100);
			}
			?>
			<tr><td class="left top  right">Modal Awal SPP/UEP<span class='pull-right'><?php echo number_format_koma($ma);?></span></td><td>&nbsp;</td></tr>
			<tr><td class="left top  right">Aset Produktif<span class='pull-right'><?php echo number_format_koma($ap);?></span></td><td>&nbsp;</td></tr>
			<tr><td class="left top  right">Perkembangan Dana<span class='pull-right'><?php echo number_format_koma($pd);?></span></td><td>&nbsp;</td></tr>
			<tr><td class="left top bottom right">Prosentase Perkembangan<span class='pull-right'><?php echo number_format_koma($pr);?>%</span></td><td>&nbsp;</td></tr>
		</table>
		
		<?php include "tanda_tangan.php"; ?> 
		
		<title>NC<?php echo "-$idf $jenis ".tgl_indo($tgl);?></title>