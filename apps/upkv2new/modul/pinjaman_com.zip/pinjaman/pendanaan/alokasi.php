<?php session_start();
include "../../../inc/inc.koneksi.php";
include "../../../inc/fungsi_indotgl.php";
include "../../../inc/terbilang.php";
ini_set('display_errors', 1); ini_set('error_reporting', E_ERROR);

$id_pinj = (isset($_GET['id_pinj'])) ? $_GET['id_pinj']:$_SESSION['idpinj'];
$pinj_a	=mysql_fetch_array(mysql_query("SELECT *, sum(alokasi) as sumalokangg FROM pinjaman_anggota_$_SESSION[kd_kab] WHERE id_pinkel='$id_pinj' "));
$sumalokangg=$pinj_a['sumalokangg'];

echo "
<input type='text' name='alokasi' id='alokasi' class='form-control input-sm text-align-center'
value='$sumalokangg' required='required' autocomplete='off' placeholder='Alokasi Kelompok'>
";

?>