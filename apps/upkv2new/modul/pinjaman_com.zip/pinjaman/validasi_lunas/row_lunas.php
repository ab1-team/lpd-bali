<?php
    include "../../../inc/inc.koneksi.php";
    include "../../../inc/fungsi_pinjaman.php";
    $views = mysql_query("SELECT * FROM kelompok_$_SESSION[kd_kab] k, pinjaman_kelompok_$_SESSION[kd_kab] pk
                            WHERE k.id=pk.id_kel AND k.lokasi='$_SESSION[lokasi]' AND pk.status='A' order by tgl_cair asc");
    
    $no=0;
    while($rows = mysql_fetch_array($views)){
        $idpinj			=$rows['id'];
        $tgl_now		=date('Y-m-d');
        $saldopinjaman	=saldopinjaman("$tgl_now-$idpinj");
        
        if ($saldopinjaman<=0) {
            $kel = mysql_query("SELECT * FROM desa d, kelompok_$_SESSION[kd_kab] k, jenis_produk_pinjaman jpp, pinjaman_kelompok_$_SESSION[kd_kab] pk
                                WHERE d.id=k.desa AND k.id=pk.id_kel AND jpp.id=pk.jenis_pp and pk.id=$idpinj ");
            while($row = mysql_fetch_array($kel)){
                $no = $no+1;
            }
        }
    }
    
    echo json_encode([
        'jumlah' => $no
    ]);
?>