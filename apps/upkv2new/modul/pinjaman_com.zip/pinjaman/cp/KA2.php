<?php session_start();
include "../../../inc/inc.koneksi.php";
include "../../../inc/terbilang.php";
include "../../../inc/fungsi_indotgl.php";
include "../../../inc/fungsi_pinjaman.php";
include "../../../js/bar128.php";			 
function tanggal($date, $id){
    $tambah = "+$id month";
    $tgl2    = date('Y-m-d', strtotime($tambah, strtotime($date))); 
    return $tgl2; 
}
?>
		<table border=1>
		    <tr>
		        <td>
		            id
		        </td>
		        <td>
		            loan id
		        </td>
		        <td>
		            angsuran ke
		        </td>
		        <td>
		            jadwal_tanggal_jatuh_tempo
		        </td>
		        <td>
		            target_pokok
		        </td>
		        <td>
		            target_jasa
		        </td>
		        <td>
		            realisasi_pokok
		        </td>
		        <td>
		            realisasi_jasa
		        </td>
		    </tr>
     	 <?php
		$rcp=$_GET['rcp'];
		$view=mysql_query("SELECT * FROM `pinjaman_kelompok_1` WHERE `status`='A' ORDER BY id ASC limit 3");
		while($row=mysql_fetch_array($view)){
		    $jangka=$row['jangka'];
		    $tgl_cair=$row['tgl_cair'];
		    ?>
		    
		    <tr>
		        <td colspan=8>
		            id
		        </td>
		    </tr>
		    
		    <?php
		for($no=1;$no<=$jangka;$no++){
		?>
		    <tr>
		        <td>
		            
		        </td>
		        <td>
		            <?php echo $no; ?>
		        </td>
		        <td>
		            <?php echo $row['id']; ?>
		        </td>
		        <td>
		            
		            <?php echo tanggal($tgl_cair,$no); ?>
		        </td>
		        <td>
		            
		            <?php echo $row['alokasi']; ?>
		        </td>
		        <td>
		            
		            <?php echo $row['jangka']; ?>
		        </td>
		        <td>
		            
		            <?php echo $row['sistem_angsuran']; ?>
		        </td>
		        <td>
		            
		            <?php echo $row['sa_jasa']; ?>
		        </td>
		    </tr>
<?php }} ?>

		</table>