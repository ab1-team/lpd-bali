<?php session_start();
include "../../../inc/inc.koneksi.php";
include "../../../inc/terbilang.php";
include "../../../inc/fungsi_indotgl.php";
include "../../../inc/fungsi_pinjaman.php";

$kec=mysql_fetch_array(mysql_query("SELECT * FROM kabupaten k, kecamatan c where k.id=c.kd_kab AND c.id='$_SESSION[lokasi]'"));

?>

<style type="text/css">
<!--
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;  }
.style9 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; }
.top	{border-top: 1px solid #000000; }
.bottom	{border-bottom: 1px solid #000000; }
.left	{border-left: 1px solid #000000; }
.right	{border-right: 1px solid #000000; }
.style26 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style27 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
.text-right {text-align:right; }
-->
</style>
<body onLoad="window.print()">


<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
           <tr>
    			<td height="20" colspan="2" class="bottom" width='7%'>
    				<div class="style9 text-align-left"><?php
                        $logo=$kec['logo'];
                          if (empty($logo)) {
                            echo "<img class='' alt='...' src='../../../images/upk.png' style='float:left; width:50; margin-right:5px;'>";
                            }else{
                            echo "<img class='' alt='...' src='../../../images/logo/$logo' style='float:left; width:50; margin-right:5px;'>";
                            }
                            echo "</td>";
                            echo"<td class='bottom'>";
                                      
                      $nomor_bh =$kec ['nomor_bh'];
                      if (empty($nomor_bh)) {$bh="";}else{$bh="Badan Hukum No.$nomor_bh<br>";}
                    
                      echo "<div class='style9'>".strtoupper("<b>$kec[nama_lembaga_long]<br>$kec[sebutan_kec] $kec[nama_kec] KABUPATEN $kec[nama_kab] </b>")."<br>$bh $kec[alamat_kec] Telp. $kec[telpon_kec] </div>"; 
                      ?>      
    				</div>
    			</td>
    			<td height="20" colspan="2" class="bottom"><div align="right" class="style9"></div></td>
    	  </tr> 
    </table>
<p align="center" class="style6">LAPORAN TAGIHAN HARI INI<br>Jatuh Tempo Tanggal : <?php echo tgl_indo(date('Y-m-d'));?> </p>
	  <table width="97%" border="0" align="center" cellpadding="3" cellspacing="0" class="top bottom left right">
      <tr>	  
          <th width="3%" height="34" class="style9 bottom top left">No</th>
			<th width="5%" class="style9 left bottom top" >LOAN ID</th>
              <th width="7%" class="style9 left bottom top">TGL CAIR</th>
              <th width="35%" class="style9 left bottom top">NAMA KELOMPOK</th>
              <th width="10%" class="style9 left bottom top">POKOK</th>
              <th width="10%" class="style9 left bottom top">JASA</th>
              <th width="10%" class="style9 left bottom top">JUMLAH</th>
              <th width="15%" class="style9 left bottom top right">KETERANGAN</th>
        </tr>      
		
<?php 	
		$tgl=date('d');
		$tgl_kondisi=date('Y-m-d');
		$table_kelompok	="kelompok_$_SESSION[kd_kab]";
		$table_pk		="pinjaman_kelompok_$_SESSION[kd_kab]";
		$view=mysql_query("SELECT * FROM desa d, $table_kelompok k, $table_pk pk 
							WHERE 
							d.id=k.desa AND k.id=pk.id_kel AND pk.status='A' AND k.lokasi='$_SESSION[lokasi]' AND substring(tgl_cair,9,2)='$tgl' AND (d.jadwal_angsuran_desa='0' OR d.jadwal_angsuran_desa='') OR
							d.id=k.desa AND k.id=pk.id_kel AND pk.status='A' AND k.lokasi='$_SESSION[lokasi]' AND d.jadwal_angsuran_desa='$tgl'
							ORDER BY pk.tgl_cair ASC ");
								$no=0;
								while($row=mysql_fetch_array($view)){
								$no=$no+1;
								$idpinj			=$row['id'];
								$tgl_cair		=$row['tgl_cair'];
								$tgl_now		=date('Y-m-d');
								
								
								
                        $jum++;
                        $tgl2    = date('Y-m-d', strtotime('+1 month', strtotime($tgl_kondisi)));
                        $ra = mysql_fetch_array(mysql_query("SELECT * FROM rencana_angsuran_$_SESSION[lokasi] WHERE loan_id=$row[id] AND jatuh_tempo<='$tgl_kondisi' ORDER BY jatuh_tempo DESC"));
    
                        $penguranganp = 0;
                        $penguranganj = 0;
                        if (!($ra)) { // jika $ra kosong (angsuran ke 0)
                            $ra = mysql_fetch_array(mysql_query("SELECT * FROM rencana_angsuran_$_SESSION[lokasi] WHERE loan_id=$row[id] AND jatuh_tempo<='$tgl2' ORDER BY jatuh_tempo DESC"));
                            if (!($ra)) { // jika $ra kosong (angsuran ke 0)
                                $ra = array("wajib_pokok" => "0", "wajib_jasa" => "0", "target_pokok" => "0", "target_jasa" => "0", "realisasi_pokok" => "0", "realisasi_jasa" => "0", "sum_pokok" => "0", "sum_jasa" => "0", "saldo_pokok" => "$row[alokasi]", "saldo_jasa" => ($row['alokasi'] * $row['pros_jasa'] * $row['jangka']), "tunggakan_pokok" => "0", "tunggakan_jasa" => "0");
                            }
                            $penguranganp = $ra['wajib_pokok'];
                            $penguranganj = $ra['wajib_jasa'];
                        }
                        $real = mysql_fetch_array(mysql_query( "SELECT *FROM real_angsuran_$_SESSION[lokasi] WHERE loan_id=$row[id] AND tgl_transaksi<='$tgl_kondisi' ORDER BY tgl_transaksi DESC, id DESC "));
                        $real2 = mysql_fetch_array(mysql_query( "SELECT sum(realisasi_pokok) as realisasi_pokok,sum(realisasi_jasa) as realisasi_jasa FROM real_angsuran_$_SESSION[lokasi] WHERE loan_id=$row[id] AND tgl_transaksi<='$tgl_kondisi' AND tgl_transaksi>='$tgl_awal' ORDER BY tgl_transaksi DESC, id DESC"));
                        if (!($real)) { // jika $ra kosong (angsuran ke 0)
                            $real = array("wajib_pokok" => "0", "wajib_jasa" => "0", "target_pokok" => "0", "target_jasa" => "0", "realisasi_pokok" => "0", "realisasi_jasa" => "0", "sum_pokok" => "0", "sum_jasa" => "0", "saldo_pokok" => "$row[alokasi]", "saldo_jasa" => ($row['alokasi'] * $row['pros_jasa'] * $row['jangka']), "tunggakan_pokok" => "0", "tunggakan_jasa" => "0");
                        }
		$noo=$noo+1;
		$idp	=$row['id'];
		$alokasi		=$row['alokasi'];
		$pros_jasa 		=number_format($row['pros_jasa'],2);
		$tgl_lunas		=$row['tgl_lunas'];
		$status			=$row['status'];
                        $target_pokok   = $ra['target_pokok'];
                        $target_jasa    = $ra['target_jasa'];
                        $mtrans         = substr($real['tgl_transaksi'], 5, 2);
                        if ($mtrans == $m) {
                            $realp          = $real2['realisasi_pokok'];
                            $realj          = $real2['realisasi_jasa'];
                        } else {
                            $realp          = 0;
                            $realj          = 0;
                        }
                        $plalu          = minimum($real['sum_pokok'] - $realp);
                        $jlalu          = minimum($real['sum_jasa'] - $realj);
                        $sum_pokok      = $real['sum_pokok'];
                        $sum_jasa       = $real['sum_jasa'];
                        $saldo_pokok    = minimum($real['saldo_pokok']);
                        $saldo_jasa    = minimum($ra['target_jasa'] - $real['sum_jasa']);
    
		//$sumpokok		=sumpokok("$tgl_kondisi-$idp"); //01.19.25
		$sumpokok		=$reallalu+$realpokok;
		//$sumjasa		=sumjasa($tgl_kondisi."-".$idp);
		$sumjasa		=$reallalujasa+$realjasa;
		//$saldopinjaman	=saldopinjaman($tgl_kondisi."-".$idp);
		$saldopinjaman	=$alokasi-$sumpokok;
		//$nunggakpokok	=nunggakpokok($tgl_kondisi."-".$idp);
		//$nunggakjasa	=nunggakjasa($tgl_kondisi."-".$idp);
		$nunggakp			=$target_pokok-$sum_pokok;
		if($nunggakp<0) { $nunggakpokok="0"; }else{ $nunggakpokok=$nunggakp; }
		$nunggakj			=$target_jasa-$sum_jasa;
		if($nunggakj<=0 OR $status=="L" AND $tgl_lunas<$tgl_kondisi ) { $nunggakjasa="0"; } else{ $nunggakjasa=$nunggakj; }
		
		$angsuranke		=$ra['angsuran_ke'];
		
								
								
								
								
								
								
								
				
						   ?>
		
		
		<!-- Menampilkan data pada tabel -->
            <tr>
              <td height="33" class="style9 top left"><div align="center" ><?php echo $no;?></div></td>
              <td class="style9 left top"><div align="center"><?php echo $idpinj;?></div></td>
              <td class="style9 left top"><div align="center"><?php echo tgl_ind($tgl_cair); ?></div></td>
              <td class="style9 left top"><span class="style9"><?php echo $row['kd_kelompok']." - ".strtoupper($row['nama_kelompok'])." ".strtoupper($row['nama_desa'])." (".$row['ketua'].")";?></span></td>
              <td class="style9 left top text-right"><?php echo number_format($nunggakpokok); ?></td>
			  <td class="style9 left top text-right"><?php echo number_format($nunggakjasa); ?></td>
			  <td class="style9 left top text-right"><?php echo number_format($nunggakpokok+$nunggakjasa); ?></td>
              <td class="style9 left top right">&nbsp;</td>
            </tr>
  <?php 
$tot_pokok	=$tot_pokok+$nunggakpokok;
$tot_jasa	=$tot_jasa+$nunggakjasa;
$tot_jumlah	=$tot_pokok+$tot_jasa;
  } ?>
			<tr>
              <th height="33" class="style9 top bottom left" colspan="4"><div align="center" >JUMLAH</div></th>
              <th class="style9 left bottom top text-right"><?php echo number_format($tot_pokok);?></th>
              <th class="style9 left bottom top text-right"><?php echo number_format($tot_jasa);?></th>
              <th class="style9 left bottom top text-right"><?php echo number_format($tot_jumlah);?></th>
              <th class="style9 left bottom top right">&nbsp;</th>
            </tr>
		<!-- Menampilkan Jumlah Total pada tabel -->
</table>

<title>LAPORAN TAGIHAN HARI INI</title>
       
</body>
