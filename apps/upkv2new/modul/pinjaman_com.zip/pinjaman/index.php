<?php
	session_destroy();
	header('Location:../../index.php?st=1');
?>