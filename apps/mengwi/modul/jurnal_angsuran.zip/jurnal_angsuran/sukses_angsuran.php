<?php session_start();
include "../../inc/inc.koneksi.php";
$table_transaksi="transaksi_".$_SESSION['lokasi'];

$idt=mysql_fetch_array(mysql_query("SELECT max(idtp) FROM $table_transaksi WHERE id_user='$_SESSION[id]' ORDER BY idtp DESC"));
$idtp			=$idt[0];
?>

<script type="text/javascript">
	function MM_openBrWindow(theURL,winName,features) { //membuka window untuk print
				window.open(theURL,winName,features);
				}	
</script>

<div class="alert alert-success mt animated fadeInDown">
    <span class="create-server-name"></span><i class="fa fa-check-circle"></i> Angsuran <strong>Berhasil </strong> di-Posting !
	<a href="javascript:;" onclick="MM_openBrWindow('modul/jurnal_angsuran/c_str_dot_1.php?&idtp=<?php echo $idtp;?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"   class="btn btn-success btn-rounded width-200 mt-sm ml-md"><i class="glyphicon glyphicon-print"></i> Cetak Struk Dot Matrik 1</a>
	<a href="javascript:;" onclick="MM_openBrWindow('modul/jurnal_angsuran/c_str_dot_2.php?&idtp=<?php echo $idtp;?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"   class="btn btn-success btn-rounded width-200 mt-sm ml-md"><i class="glyphicon glyphicon-print"></i> Cetak Struk Dot Matrik 2</a>
	
	<a href="javascript:;" onclick="MM_openBrWindow('modul/jurnal_angsuran/c_str.php?&idtp=<?php echo $idtp;?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"   class="btn btn-success btn-rounded width-200 mt-sm ml-md"><i class="glyphicon glyphicon-print"></i> Cetak Struk</a>
	
	<a href="javascript:;" onclick="MM_openBrWindow('modul/jurnal_angsuran/c_ka.php?&idtp=<?php echo $idtp;?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"   class="btn btn-success btn-rounded width-200 mt-sm ml-md"><i class="glyphicon glyphicon-print"></i> Cetak pada Kartu</a>
</div>