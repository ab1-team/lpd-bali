<?php session_start();
include "../../inc/inc.koneksi.php";
include "../../inc/fungsi_indotgl.php";
include "../../inc/fungsi_pinjaman.php";


$row=mysql_fetch_array(mysql_query("SELECT * FROM desa d, sebutan_desa sd, kelompok_$_SESSION[kd_kab] k, jenis_produk_pinjaman jpp, sistem_angsuran sa, jenis_jasa jj, pinjaman_kelompok_$_SESSION[kd_kab] pk WHERE jpp.id=pk.jenis_pp AND sd.id=d.sebutan AND jj.id=pk.jenis_jasa AND sa.id=pk.sistem_angsuran AND k.desa=d.id and k.id=pk.id_kel AND k.lokasi='$_SESSION[lokasi]' AND pk.status='A' AND pk.id= '$_SESSION[id_pinj]' "));
	
$jum_angsuran	=@($row['jangka']/$row['sistem']);
$id_pinj		=$row['id'];
$sistem			=$row['sistem'];
$alokasi			=$row['alokasi'];
$tgl_cair			=$row['tgl_cair'];
$pros_jasa			=$row['pros_jasa'];
$jenis_jasa			=$row['jenis_jasa'];
$nama_jj			=$row['nama_jj'];
$jangka				=$row['jangka'];
$sistem				=$row['sistem'];
$tempo				=@($jangka/$sistem);
$datenow		=date('Y-m-d');
$tottargetpokok	=targetpokok("$datenow-$id_pinj");
$tottargetjasa		=targetjasa("$datenow-$id_pinj");
$sumpokok		=sumpokok("$datenow-$id_pinj");
$sumjasa		=sumjasa("$datenow-$id_pinj");
$totsaldopinjaman	=saldopinjaman("$datenow-$id_pinj");
$totsaldojasa	=saldo_jasa("$datenow-$id_pinj");
$totnunggakpokok	=nunggakpokok("$datenow-$id_pinj");
$totnunggakjasa	=nunggakjasa("$datenow-$id_pinj");


											
echo "
<section class='widget bg-primary text-white'>
<div class='widget-body clearfix'>	";
?>

<div class="widget-top-overflow windget-padding-md clearfix" style="background-color:#00008B;">
							<span class="h4 text-white"><i class="fa fa-group"></i> <b><?php echo strtoupper("$row[nama_kelompok] $row[nama_desa]");?></b>
								<ul class="tags text-white pull-right">
									<li><a href="javascript:;" onclick="MM_openBrWindow('modul/pinjaman/cp/KA.php?&rcp=<?php echo $row['id'];?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )" > <span class="fs-mini">Kartu Angsuran</span></a></li>
									<li><a href="javascript:;" onclick="MM_openBrWindow('modul/jurnal_angsuran/c_RK.php?&idp=<?php echo $row['id'];?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )" > <span class="fs-mini">Riwayat Angsuran</span></a></li>
								</ul>
							</span>
						</div>
						
<?php
echo "	<br>				
    <table width='100%'>
		<tr><td width='19%'>ID Kelompok</td><td>:</td width='1%'><td width='30%'><strong>$row[kd_kelompok]</strong></td>	<td width='19%'>Loan ID</td><td width='1%'>:</td><td width='30%'><strong>$row[nama_jpp]-$row[id]</strong></td></tr>
		<tr><td>Nama Kelompok</td><td>:</td><td><strong>$row[nama_kelompok]</strong></td>									<td>SPK Nomor</td><td>:</td><td><strong>$row[spk_no]</strong></td></tr>
		<tr><td>Alamat</td><td>:</td><td><strong>$row[alamat_kelompok]</strong></td>									<td>Tanggal Cair</td><td>:</td><td><strong>$row[tgl_cair]</strong></td></tr>
		<tr><td>$row[sebutan_desa]</td><td>:</td><td><strong>$row[nama_desa]</strong></td>										<td>Alokasi</td><td>:</td><td><strong>".number_format($row['alokasi'])."</strong></td></tr>
		<tr><td>Telpon</td><td>:</td><td><strong>$row[telpon]</strong></td>									<td>Jasa</td><td>:</td><td><strong>$pros_jasa</strong>% <strong>$nama_jj</strong></td></tr>
		<tr><td>Nama Ketua</td><td>:</td><td><strong>$row[ketua]</strong></td>													<td>Sistem Angsuran</td><td>:</td><td><strong>$row[jangka]</strong> bulan @<strong>$row[nama_sistem]</strong></td></tr>
		<tr><td>Nama Sekretrais</td><td>:</td><td><strong>$row[sekretaris]</strong></td>												<td>Angsuran</td><td>:</td><td><strong>".number_format(wajibpokokaja($id_pinj)+(wajibjasaaja($id_pinj)*$sistem))."</strong> x <strong>$jum_angsuran</strong></td></tr>
    </table>
</div>

";


 ?>

 
  <table class="table table-bordered table-emails fs-sm mt text-align-center">
                        <thead>
		<tr>
			<td rowspan="2">Ke</td>
			<td rowspan="2">Bulan</td>
			<td colspan="2">Target</td>
			<td colspan="2">Realisasi</td>
			<td colspan="2">Saldo</td>
			<td colspan="2">Tunggakan</td>
		</tr>	  
		<tr>	  
            <td width="10%">Pokok</td>
            <td width="10%">Jasa</td>
			<td width="10%">Pokok</td>
            <td width="10%">Jasa</td>
            <td width="10%">Pokok</td>
            <td width="10%">Jasa</td>
			<td width="10%">Pokok</td>
            <td width="10%">Jasa</td>
        </tr>      
	</thead>
                        <tbody>
		
		
		<!-- Menampilkan data pada tabel -->
            <tr>			  
			  <td><div align="center"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			
				$tanggal  			 = substr($tgl_cair,8,2);
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
			  
			    $date	="$td-$bln";
				$datenow=date('Y-m');
			
			if($date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>$noo</div><br>"; 
			  }else{
			  echo "$noo<br><br>"; 
			  }


			  } ?> <i class="fa fa-warning"></i></div></td>
			  
			  <td><div align="center"><?php 
			  //Tanggal
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			
				$tanggal  			 = substr($tgl_cair,8,2);
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
			  
			    $date	="$td-$bln";
				$datenow=date('Y-m');
			
			if($date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>$td-$bln</div><br>"; 
			  }else{
			  echo "$td-$bln<br><br>"; 
			  }


			  } 
			  //End Tanggal
			  ?> Zona Merah </div></td>
			  
			  
			  <td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
			
			  $date	="$td-$bln";
				$datenow=date('Y-m');
			
			$targetpokok=targetpokok("$td-$bln-$tanggal-$id_pinj");	
			
			if($date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($targetpokok)."</div><br>"; 
			  }else{
			  echo "".number_format($targetpokok)."<br><br>"; 
			  }


			  } ?> - </div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
			
			$targetjasa=targetjasa("$td-$bln-$tanggal-$id_pinj");	
			
			if($date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($targetjasa)."</div><br>"; 
			  }else{
			  echo "".number_format($targetjasa)."<br><br>"; 
			  }
			  
			  } ?> - </div></td>
			  
			  <td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
				
			$realisasiinipokok=realisasiinipokok("$td-$bln-$tanggal-M-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($realisasiinipokok)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($realisasiinipokok)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } 
			 
			 //Mencari Transaksi diatas Tanggal Target Tempo (Zona Merah)
			$bm  			 = substr($tgl_cair,5,2)+$tempo+1;
			$tm  			 = substr($tgl_cair,0,4);
			
			if ($bm>12 and $bm<=24){
			  $blm=$bm-12;
			  $thm=$tm+1;
			  }else if ($bm>24){
			  $blm=$bm-24;
			  $thm=$tm+2;
			  }else{
			  $blm=$bm;
			  $thm=$tm;
			  }
			  
				if ($blm<10){
				$blnm="0$blm";
				}else{
				$blnm=$blm;
				}
				
				$datenow=date('Y-m');
				$datem	="$thm-$blnm";
				$realisasimerahpokok=realisasimerahpokok("$datem-01-$id_pinj");
				
			if($datem <= $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($realisasimerahpokok)."</div>"; 
			  }else{
			  echo "0"; 
			  }

//End Zona Merah			
			 ?></div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
				
			$realisasiinijasa=realisasiinijasa("$td-$bln-$tanggal-M-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($realisasiinijasa)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($realisasiinijasa)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } 
			 
//Mencari Transaksi diatas Tanggal Target Tempo (Zona Merah)
			$bm  			 = substr($tgl_cair,5,2)+$tempo+1;
			$tm  			 = substr($tgl_cair,0,4);
			
			if ($bm>12 and $bm<=24){
			  $blm=$bm-12;
			  $thm=$tm+1;
			  }else if ($bm>24){
			  $blm=$bm-24;
			  $thm=$tm+2;
			  }else{
			  $blm=$bm;
			  $thm=$tm;
			  }
			  
				if ($blm<10){
				$blnm="0$blm";
				}else{
				$blnm=$blm;
				}
				
				$datenow=date('Y-m');
				$datem	="$thm-$blnm";
				$realisasimerahjasa=realisasimerahjasa("$datem-01-$id_pinj");
				
			if($datem <= $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($realisasimerahjasa)."</div>"; 
			  }else{
			  echo "0"; 
			  }

//End Zona Merah
?></div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
				
			$saldopinjaman=saldopinjaman("$td-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($saldopinjaman)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($saldopinjaman)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?>-</div></td>
			 
			 <td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
				
			$saldo_jasa=saldo_jasa("$td-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($saldo_jasa)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($saldo_jasa)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?>-</div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
				
			$nunggakpokok=nunggakpokok("$td-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($nunggakpokok)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($nunggakpokok)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?>-</div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $td=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $td=$tahun+2;
			  }else{
			  $bl=$b;
			  $td=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$td-$bln";
			$datenow=date('Y-m');
				
			$nunggakjasa=nunggakjasa("$td-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($nunggakjasa)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-warning fw-semi-bold'>".number_format($nunggakjasa)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?>-</div></td>
			  
			
			  
			  
			  
			  
            </tr>

		
		<!-- Menampilkan Jumlah Total pada tabel -->
		 <tr>	  
          <td width="2%" colspan="2" class="text-align-center">REKAPITULASI</td>
              <td width="10%" class="text-align-right"><?php echo number_format($tottargetpokok); ?></td>
              <td width="10%" class="text-align-right"><?php echo number_format($tottargetjasa); ?></td>
			  <td width="10%" class="text-align-right"><?php echo number_format($sumpokok); ?></td>
			  <td width="10%" class="text-align-right"><?php echo number_format($sumjasa); ?></td>
			  <td width="10%" class="text-align-right"><?php echo number_format($totsaldopinjaman); ?></td>
			  <td width="10%" class="text-align-right"><?php echo number_format($totsaldojasa); ?></td>
			  <td width="10%" class="text-align-right"><?php echo number_format($totnunggakpokok); ?></td>
			  <td width="10%" class="text-align-right"><?php echo number_format($totnunggakjasa); ?></td>
        </tr> 
	</tbody>
</table>
 
</section>