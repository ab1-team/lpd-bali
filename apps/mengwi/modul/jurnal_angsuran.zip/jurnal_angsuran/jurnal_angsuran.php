<script type="text/javascript">
	window.onload = function() {
		var input = document.getElementById("id_kelompok").focus();
		}
		
	$(document).ready(function() {
		
		$("#TampilKelompok").load('modul/jurnal_angsuran/tampil_kelompok.php');
		$("#FormAngsuran").load('modul/jurnal_angsuran/form_angsuran.php');
		$("#Progres").load('modul/jurnal_angsuran/tampil_progres.php');
		
		//UNTUK MENAPILKAN KELOMPOK
				$("#kelompok").click(function(){
						var cari = $("#kelompok").val();
						kelompok(cari);
						kelompoka(cari);
					})
					function kelompok(e){
						var cari = e;
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal_angsuran/form_angsuran.php",
							data	: "cari="+cari,
							success	: function(data){
								$("#FormAngsuran").html(data);
								$("#TampilBuku").load('modul/jurnal_angsuran/tampil_buku_angsuran.php');
								$("#Progres").load('modul/jurnal_angsuran/tampil_progres.php');
							}
						});
					}
					
					function kelompoka(e){
						var cari = e;
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal_angsuran/tampil_kelompok.php",
							data	: "cari="+cari,
							success	: function(data){
								$("#TampilKelompok").html(data);
							}
						});
					}
					
				$("#id_kelompok").keyup(function(){
						var id_kelompok = $("#id_kelompok").val();
						cariidkelompok(id_kelompok);
					})
					function cariidkelompok(ck){
						var id_kelompok = ck;
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal_angsuran/form_angsuran.php",
							data	: "id_kelompok="+id_kelompok,
							success	: function(data){
								$("#FormAngsuran").html(data);
								$("#TampilBuku").load('modul/jurnal_angsuran/tampil_buku_angsuran.php');
								$("#TampilKelompok").load('modul/jurnal_angsuran/tampil_kelompok.php');
								$("#Progres").load('modul/jurnal_angsuran/tampil_progres.php');
							}
						});
					}
	
	});		
</script>

		<div class="row">
            <div class="col-md-12 col-md-offset hidden-print">
                <section class="widget">
                    <div class="widget-body">
						<legend><h3>Jurnal Khusus Angsuran <span class="fw-semi-bold">Pinjaman Kelompok</span></h3></legend>
						
						<div class="row">
							<div class="col-md-5 col-md-offset hidden-print">
								<section class="widget">
									<div class="widget-body">
										<div id="validation-form" class="form-horizontal form-label-left" method="post"
											  data-parsley-priority-enabled="false"
											  novalidate="novalidate">
											<fieldset>
												<div class="input-group">
													<span class="input-group-addon"><i class="glyphicon glyphicon-barcode"></i></span>
													<input type="text" name="id_kelompok" id="id_kelompok" class="form-control" 
														required="required" autocomplete="off" placeholder="Scan Barcode ID Kelompok disini">	
												</div>
													<p class="text-muted mt mb text-align-center">- atau -</p>
												<div class="input-group">
															<span class="input-group-addon"><i class="fa fa-users"></i></span>
															<select id="kelompok"  name="kelompok"
																data-placeholder="Cari Nama Kelompok dari Data Base"
																class="select2 form-control lg"
																tabindex="-1">
																<option value=""></option>
																	<?php 
																	$view=mysql_query("select * from kecamatan c, desa d, pinjaman_kelompok_$_SESSION[kd_kab] pk, kelompok_$_SESSION[kd_kab] k where c.kd_kec=d.kd_kec and k.id=pk.id_kel AND pk.status='A' AND c.id='$_SESSION[lokasi]' and k.lokasi=c.id and k.desa=d.id order by d.id asc"); //KELOMPOK
																		while($row=mysql_fetch_array($view)){
																		echo "<option value='$row[id]'>$row[nama_desa] | $row[nama_kelompok]</option>";
																		} ?>
															</select>
												</div>	
												<div id="Progres"></div>
												<div class="form-group">
													<label class="control-label col-md-4">Tanggal Transaksi</label>
													<div class="col-md-8"><input id="datetimepicker1" type="text" value="<?php echo date('Y-m-d');?>" data-date-format="YYYY-MM-DD" class="form-control" /></div>
												</div>												
											</fieldset>
											
											<div id="FormAngsuran"></div>
										</div>
									</div>
								</section>
								
							</div>
							<div class="col-md-7">
								<div id="TampilKelompok"></div>
							</div>
						</div>
						
                    </div>
                </section>
            </div>
	
	<div class="col-md-12">
            <div id="TampilBuku"></div>
	</div>
</div>