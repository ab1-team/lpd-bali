<script type="text/javascript">
	window.onload = function() {
		var input = document.getElementById("nik").focus();
		}
		
	$(document).ready(function() {
		
		$("#TampilKelompok").load('modul/jurnal_angsuran/tampil_individu.php');
		$("#FormAngsuran").load('modul/jurnal_angsuran/form_angsuran_individu.php');
	
		//UNTUK MENAPILKAN KELOMPOK
				$("#individu").click(function(){
						var cari = $("#individu").val();
						individu(cari);
						kelompoka(cari);
					})
					function individu(e){
						var cari = e;
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal_angsuran/form_angsuran_individu.php",
							data	: "cari="+cari,
							success	: function(data){
								$("#FormAngsuran").html(data);
								$("#TampilBuku").load('modul/jurnal_angsuran/tampil_buku_angsuran_individu.php');
								
							}
						});
					}
					
					function kelompoka(e){
						var cari = e;
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal_angsuran/tampil_individu.php",
							data	: "cari="+cari,
							success	: function(data){
								$("#TampilKelompok").html(data);
							}
						});
					}
					
				$("#nik").keyup(function(){
						var nik = $("#nik").val();
						cariidkelompok(nik);
					})
					function cariidkelompok(ck){
						var nik = ck;
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal_angsuran/form_angsuran_individu.php",
							data	: "nik="+nik,
							success	: function(data){
								$("#FormAngsuran").html(data);
								$("#TampilBuku").load('modul/jurnal_angsuran/tampil_buku_angsuran.php');
								$("#TampilKelompok").load('modul/jurnal_angsuran/tampil_individu.php');
							}
						});
					}
	
	});		
</script>

		<div class="row">
            <div class="col-md-12 col-md-offset hidden-print">
                <section class="widget">
                    <div class="widget-body">
						<legend><h3>Jurnal Khusus Angsuran <span class="fw-semi-bold">Pinjaman Individu</span></h3></legend>
						
						<div class="row">
							<div class="col-md-5 col-md-offset hidden-print">
								<section class="widget">
									<div class="widget-body">
										<div id="validation-form" class="form-horizontal form-label-left" method="post"
											  data-parsley-priority-enabled="false"
											  novalidate="novalidate">
											<fieldset>
												<div class="input-group">
													<span class="input-group-addon"><i class="glyphicon glyphicon-barcode"></i></span>
													<input type="text" name="nik" id="nik" class="form-control" 
														required="required" autocomplete="off" placeholder="Scan Barcode ID Anggota / NIK disini">	
												</div>
													<p class="text-muted mt mb text-align-center">- atau -</p>
												<div class="input-group">
															<span class="input-group-addon"><i class="fa fa-users"></i></span>
															<select id="individu"  name="individu"
																data-placeholder="Cari Nama Anggota Pemanfaat dari Data Base"
																class="select2 form-control lg"
																tabindex="-1">
																<option value=""></option>
																	<?php 
																	$view=mysql_query("select * from kecamatan c, desa d, pinjaman_anggota_$_SESSION[kd_kab] pi, anggota_$_SESSION[kd_kab] k where c.kd_kec=d.kd_kec and k.id=pi.nia AND pi.status='A' AND c.id='$_SESSION[lokasi]' and k.lokasi=c.id and k.desa=d.id AND pi.jenis_pinjaman='I' order by d.id asc"); //KELOMPOK
																		while($row=mysql_fetch_array($view)){
																		echo "<option value='$row[id]'>$row[nama_desa] | $row[namadepan]</option>";
																		} ?>
															</select>
												</div>											
											</fieldset>
											<div id="FormAngsuran"></div>
										</div>
									</div>
								</section>
								
							</div>
							<div class="col-md-7">
								<div id="TampilKelompok"></div>
							</div>
						</div>
						
                    </div>
                </section>
            </div>
	
	<div class="col-md-12">
            <div id="TampilBuku"></div>
	</div>
</div>