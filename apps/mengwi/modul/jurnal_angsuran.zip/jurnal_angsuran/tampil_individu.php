<?php session_start();
include "../../inc/inc.koneksi.php";
include "../../inc/fungsi_indotgl.php";
include "../../inc/fungsi_pinjaman_individu.php";


$row=mysql_fetch_array(mysql_query("SELECT * FROM desa d, sebutan_desa sd, anggota_$_SESSION[kd_kab] a, jenis_produk_pinjaman jpp, sistem_angsuran sa, jenis_jasa jj, pinjaman_anggota_$_SESSION[kd_kab] pi WHERE jpp.id=pi.jenis_pp AND sd.id=d.sebutan AND jj.id=pi.jenis_jasa AND sa.id=pi.sistem_angsuran AND a.desa=d.id and a.id=pi.nia AND a.lokasi='$_SESSION[lokasi]' AND pi.status='A' AND pi.id= '$_SESSION[id_pinj]' "));
	
$jum_angsuran	=@($row['jangka']/$row['sistem']);
$id_pinj		=$row['id'];
$sistem			=$row['sistem'];
$alokasi			=$row['alokasi'];
$tgl_cair			=$row['tgl_cair'];
$pros_jasa			=$row['pros_jasa'];
$jenis_jasa			=$row['jenis_jasa'];
$nama_jj			=$row['nama_jj'];
$jangka				=$row['jangka'];
$sistem				=$row['sistem'];
$tempo				=@($jangka/$sistem);
$datenow		=date('Y-m-d');
$tottargetpokok	=targetpokok("$datenow-$id_pinj");
$tottargetjasa		=targetjasa("$datenow-$id_pinj");
$sumpokok		=sumpokok("$datenow-$id_pinj");
$sumjasa		=sumjasa("$datenow-$id_pinj");
$totsaldopinjaman	=saldopinjaman("$datenow-$id_pinj");
$totnunggakpokok	=nunggakpokok("$datenow-$id_pinj");
$totnunggakjasa	=nunggakjasa("$datenow-$id_pinj");
											
echo "						
<div class='alert alert-$row[warna_jpp]'>
    <table width='100%'>
		<tr><td width='19%'>N I K</td><td>:</td width='1%'><td width='30%'><strong>$row[nik]</strong></td>					<td width='19%'>Loan ID</td><td width='1%'>:</td><td width='30%'><strong>$row[nama_jpp]-$row[id]</strong></td></tr>
		<tr><td>Nama Pemanfaat</td><td>:</td><td><strong>$row[namadepan]</strong></td>										<td>Tanggal Cair</td><td>:</td><td><strong>$row[tgl_cair]</strong></td></tr>
		<tr><td>Alamat</td><td>:</td><td><strong>$row[alamat]</strong></td>													<td>Alokasi</td><td>:</td><td><strong>".number_format($row['alokasi'])."</strong></td></tr>
		<tr><td>$row[sebutan_desa]</td><td>:</td><td><strong>$row[nama_desa]</strong></td>									<td>Bagi Hasil</td><td>:</td><td><strong>$pros_jasa</strong>% <strong>$nama_jj</strong></td></tr>
		<tr><td>Telpon</td><td>:</td><td><strong>$row[telpon]</strong></td>													<td>Sistem Angsuran</td><td>:</td><td><strong>$row[jangka]</strong> bulan @<strong>$row[nama_sistem]</strong></td></tr>
		<tr><td>Nama Penjamin</td><td>:</td><td><strong>$row[penjamin]</strong></td>												<td>Angsuran</td><td>:</td><td><strong>".number_format(wajibpokokaja($id_pinj)+(wajibjasaaja($id_pinj)*$sistem))."</strong> x <strong>$jum_angsuran</strong></td></tr>
    </table>
</div>
";

 ?>
 
  <table class="table table-bordered table-emails fs-mini">
                        <thead>
		<tr>
			<th rowspan="2">Ke</th>
			<th rowspan="2">Tanggal</th>
			<th colspan="2">Target</th>
			<th colspan="2">Realisasi</th>
			<th rowspan="2">Saldo Pinjaman</th>
			<th colspan="2">Tunggakan</th>
		</tr>	  
		<tr>	  
            <th width="10%">Pokok</th>
            <th width="10%">Bagi Hasil</th>
			<th width="10%">Pokok</th>
            <th width="10%">Bagi Hasil</th>
            <th width="10%">Pokok</th>
            <th width="10%">Bagi Hasil</th>
        </tr>      
	</thead>
                        <tbody>
		
		
		<!-- Menampilkan data pada tabel -->
            <tr>			  
			  <td><div align="center"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			
				$tanggal  			 = substr($tgl_cair,8,2);
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
			  
			    $date	="$th-$bln";
				$datenow=date('Y-m');
			
			if($date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>$noo</div><br>"; 
			  }else{
			  echo "$noo<br><br>"; 
			  }


			  } ?> ></div></td>
			  
			  <td><div align="center"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			
				$tanggal  			 = substr($tgl_cair,8,2);
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
			  
			    $date	="$th-$bln";
				$datenow=date('Y-m');
			
			if($date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>$tanggal/$bln/$th</div><br>"; 
			  }else{
			  echo "$tanggal/$bln/$th<br><br>"; 
			  }


			  } ?> >>>>> </div></td>
			  
			  
			  <td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
			
			  $date	="$th-$bln";
				$datenow=date('Y-m');
			
			$targetpokok=targetpokok("$th-$bln-$tanggal-$id_pinj");	
			
			if($date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($targetpokok)."</div><br>"; 
			  }else{
			  echo "".number_format($targetpokok)."<br><br>"; 
			  }


			  } ?> - </div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$th-$bln";
			$datenow=date('Y-m');
			
			$targetjasa=targetjasa("$th-$bln-$tanggal-$id_pinj");	
			
			if($date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($targetjasa)."</div><br>"; 
			  }else{
			  echo "".number_format($targetjasa)."<br><br>"; 
			  }
			  
			  } ?> -- </div></td>
			  
			  <td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$th-$bln";
			$datenow=date('Y-m');
				
			$realisasiinipokok=realisasiinipokok("$th-$bln-$tanggal-M-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($realisasiinipokok)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($realisasiinipokok)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?></div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$th-$bln";
			$datenow=date('Y-m');
				
			$realisasiinijasa=realisasiinijasa("$th-$bln-$tanggal-M-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($realisasiinijasa)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($realisasiinijasa)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?></div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$th-$bln";
			$datenow=date('Y-m');
				
			$saldopinjaman=saldopinjaman("$th-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($saldopinjaman)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($saldopinjaman)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?></div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$th-$bln";
			$datenow=date('Y-m');
				
			$nunggakpokok=nunggakpokok("$th-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($nunggakpokok)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($nunggakpokok)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?></div></td>
			  
			<td><div align="right"><?php 
			  
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = "31";
				$bulan  			 = substr($tgl_cair,5,2);
				$tahun  			 = substr($tgl_cair,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
			  if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			$date	="$th-$bln";
			$datenow=date('Y-m');
				
			$nunggakjasa=nunggakjasa("$th-$bln-$tanggal-$id_pinj");
			if($date <= $datenow and $date != $datenow) {
			  echo "".number_format($nunggakjasa)."<br><br>"; 
			  }else if($date <= $datenow and $date == $datenow) {
			  echo "<div class='text-danger fw-semi-bold'>".number_format($nunggakjasa)."</div><br>"; 
			  }else{
			  echo "0<br><br>"; 
			  }
			 
			 } ?></div></td>
			  
			
			  
			  
			  
			  
            </tr>

		
		<!-- Menampilkan Jumlah Total pada tabel -->
		 <tr>	  
          <th width="2%" colspan="2" class="text-align-center">REKAPITULASI</th>
              <th width="10%" class="text-align-right"><?php echo number_format($tottargetpokok); ?></th>
              <th width="10%" class="text-align-right"><?php echo number_format($tottargetjasa); ?></th>
			  <th width="10%" class="text-align-right"><?php echo number_format($sumpokok); ?></th>
			  <th width="10%" class="text-align-right"><?php echo number_format($sumjasa); ?></th>
			  <th width="10%" class="text-align-right"><?php echo number_format($totsaldopinjaman); ?></th>
			  <th width="10%" class="text-align-right"><?php echo number_format($totnunggakpokok); ?></th>
			  <th width="10%" class="text-align-right"><?php echo number_format($totnunggakjasa); ?></th>
        </tr> 
	</tbody>
</table>
 
 