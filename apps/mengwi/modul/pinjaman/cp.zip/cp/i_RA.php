<?php session_start();
include "../../../inc/inc.koneksi.php";
include "../../../inc/terbilang.php";
include "../../../inc/fungsi_indotgl.php";
include "../../../inc/fungsi_pinjaman_individu.php";

?>

<style type="text/css">
<!--
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 16px;  }
.style9 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; }
.top	{border-top: 1px solid #000000; }
.bottom	{border-bottom: 1px solid #000000; }
.left	{border-left: 1px solid #000000; }
.right	{border-right: 1px solid #000000; }
.style26 {font-family: Verdana, Arial, Helvetica, sans-serif}
.style27 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; }
-->
</style>
<body onLoad="window.print()">

     	   <?php
		$rcp=$_GET['rcp'];
		$view=mysql_query("select * from kabupaten b, kecamatan kc, desa d, sebutan_desa sd, jenis_produk_pinjaman jpp, sistem_angsuran sa, jenis_jasa jj, usaha us,
													anggota_$_SESSION[kd_kab] a, pinjaman_anggota_$_SESSION[kd_kab] pi
																WHERE
																b.id=kc.kd_kab AND kc.id=a.lokasi AND d.id=a.desa AND sd.id=d.sebutan AND jpp.id=pi.jenis_pp AND
																sa.id=pi.sistem_angsuran AND jj.id=pi.jenis_jasa AND us.id=a.usaha AND
																a.id=pi.nia AND pi.id='$rcp'");
		$no=0;
		while($row=mysql_fetch_array($view)){
		
											$id_pinj			=$row['id'];
											$jenis_pp			=$row['jenis_pp'];
											$tgl_proposal		=$row['tgl_proposal'];
											$proposal			=$row['proposal'];
											$tgl_verifikasi		=$row['tgl_verifikasi'];
											
											$tgl_cair			=$row['tgl_cair'];
											$alokasi			=$row['alokasi'];
											$pros_jasa			=$row['pros_jasa'];
											$jenis_jasa			=$row['jenis_jasa'];
											$nama_jj			=$row['nama_jj'];
											$jangka				=$row['jangka'];
											
											$sa_pokok			=$row['sistem'];
											
											//Sistem Angsuran
			$sj	=mysql_fetch_array(mysql_query("SELECT * FROM  sistem_angsuran sa, pinjaman_anggota_$_SESSION[kd_kab] pi WHERE sa.id=pi.sa_jasa AND pi.id='$id_pinj' "));
				$sa_jasa	=$sj['sistem'];
				if ($sa_pokok>=$sa_jasa) {$sistem=$sa_jasa;}elseif ($sa_jasa>$sa_pokok) {$sistem=$sa_pokok;}
											
											
											$tempo				=@($jangka/$sistem);
											$temp				=$tempo/2;
											if($temp<=1) {$tempe="1"; $bulangs=$bulan+$sistem;} elseif($temp<=3) {$tempe="3"; $bulangs=$bulan+$sistem;} else{$tempe=$temp; $bulangs=$bulan+1;}
											
			//Tempo Pokok
			$tempo_pokok		=$jangka/$sa_pokok;
			$temp_pokok			=$tempo_pokok/2;
			if($temp_pokok<=1) {$tempe_pokok="1"; $bulangs=$bulan+$sa_pokok;} elseif($temp_pokok<=3) {$tempe_pokok="3"; $bulangs=$bulan+$sa_pokok;} else{$tempe_pokok=$temp_pokok; $bulangs=$bulan+1;}
				
											$sistem_angsuran	=$row['nama_sistem'];
											
											$lu					=$row['lu'];
											$status				=$row['status'];
											$user_id			=$row['user_id'];
											$dus				=mysql_fetch_array(mysql_query("SELECT * FROM users u, level l WHERE u.level=l.id AND u.id='$user_id' "));
											$nama_user			=$dus['namadepan']. " " .$dus['namabelakang']." (".$dus['nama_level'].")";
											
											$nama_lembaga_sort	=$row ['nama_lembaga_sort'];
											$nama_lembaga_long	=$row ['nama_lembaga_long'];
											$lokasi				=$row['lokasi'];
											$nama_kec			=$row['nama_kec'];
											$sebutan_kec		=$row['sebutan_kec'];
											$nama_kab			=$row['nama_kab'];
											$nama_desa			=$row['nama_desa'];
											$sebutan_desa		=$row['sebutan_desa'];
											$sebutan_kades		=$row['sebutan_kades'];
											$nik				=$row['nik'];
											$namadepan			=$row['namadepan'];
											$alamat				=$row['alamat'];
											$telpon				=$row['telpon'];
											$tempat_lahir		=$row['tempat_lahir'];
											$tgl_lahir			=$row['tgl_lahir'];
											$nama_jpp			=$row['nama_jpp'];
											$jenis_usaha		=$row['nama_usaha'];
											$jenis_kelamin		=$row['jk'];
											$nomor_kk			=$row['kk'];
											$penjamin			=$row['penjamin'];
											$hubungan			=$row['hubungan'];
											$lo					=$row['lo'];
											$uname				=$row['uname'];
											$pass				=$row['pass'];
											$tgl_now			=date('Y-m-d');
											
											if($status=="P"){$tglstatus=$tgl_proposal; $ket="Tanggal Proposal"; $dok="Proposal";
											}else if($status=="V"){$tglstatus=$tgl_verifikasi; $ket="Tanggal Verifikasi"; $dok="Verifikasi";
											}else if($status=="W" or $status=="A"){$tglstatus=$tgl_cair; $ket="Tanggal Cair"; $dok="Pencairan";
											}
											$ketuaupk			=mysql_fetch_array(mysql_query("SELECT * FROM users WHERE lokasi='$lokasi' AND level='1' AND jabatan='1' AND sejak<='$tglstatus' "));
											$ketuabkad			=mysql_fetch_array(mysql_query("SELECT * FROM users WHERE lokasi='$lokasi' AND level='2' AND jabatan='1' AND sejak<='$tglstatus' "));
				
			?>			
		
    <table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">
       <tr>
			<td height="20" colspan="2" class="bottom">
				<div class="style9 text-align-left"><?php
                    $logo=$row['logo'];
                      if (empty($logo)) {
                        echo "<img class='' alt='...' src='../../../images/upk.png' style='float:left; width:50; margin-right:5px;'>";
                        }else{
                        echo "<img class='' alt='...' src='../../../images/logo/$logo' style='float:left; width:50; margin-right:5px;'>";
                        }
                                  
                  $nomor_bh =$row ['nomor_bh'];
                  if (empty($nomor_bh)) {$bh="";}else{$bh="Badan Hukum No.$nomor_bh<br>";}
                
                  echo "<div class='style9'>".strtoupper("<b>$row[nama_lembaga_long]<br>$sebutan_kec $row[nama_kec] KABUPATEN $row[nama_kab]</b>")."<br>$bh $row[alamat_kec] Telp. $row[telpon_kec] </div>"; 
                  ?>      
				</div>
			</td>
			<td height="20" colspan="2" class="bottom"><div align="right" class="style9">Dokumen Pencairan<br>
			Loan ID. <?php echo "$id_pinj";?>
			Lamp-8</div></td>
	  </tr> 
</table>
<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0">

      <tr>
        <td height="20" colspan="4" class="bottom"><p align="center" class="style6">
		RENCANA ANGSURAN<br>
		<span class="fw-semi-bold">PINJAMAN INDIVIDU  <?php echo $nama_jpp;?></p></td>
      </tr>
      <tr>
        <td width="19%" height="24" class="style9">Nama Pemanfaat</td>
        <td width="32%" height="24"><span class="style9">:</span><span class="style27"> <?php echo strtoupper($namadepan);?></span></td>
        <td width="19%" height="24" class="style9">Alokasi Pinjaman</td>
        <td width="30%" height="24"><span class="style9">:</span><span class="style27"> Rp. <?php echo number_format($alokasi);?>,-</span></td>
      </tr>
      <tr>
        <td height="24" class="style9">Alamat</td>
        <td height="24"><span class="style9">:</span><span class="style27"> <?php echo $alamat;?></span></td>
        <td height="24" class="style9"> Sistem Angsuran </td>
        <td height="24"><span class="style9">:</span><span class="style27"> <?php echo "$sistem_angsuran ($jangka bulan)";?></span></td>
      </tr>
      <tr>
        <td height="25" class="style9"><?php echo $ket;?></td>
        <td height="25"><span class="style9">:</span><span class="style27"> <?php echo tgl_indo($tglstatus); ?></span></td>
        <td height="25" class="style9">Sistem Bagi Hasil </td>
        <td height="25"><span class="style9">:</span><span class="style27"> <?php echo "$pros_jasa %/bulan, $nama_jj";?> </span></td>
      </tr>  
</table>
<br>
	  <table width="97%" border="0" align="center" cellpadding="5" cellspacing="0" class="top bottom left right">
      <tr>	  
          <th width="2%" height="34" class="style9 bottom top left right">Ansuran Ke</th>
			<th width="10%" class="style9 bottom top">Tanggal</th>
              <th width="10%" class="style9 left bottom top">Pokok</th>
              <th width="10%" class="style9 left bottom top">Jasa <?php echo $pros_jasa;?>%</th>
              <th width="10%" class="style9 left bottom top">Jumlah</th>
              <th width="10%" class="style9 left bottom top">Total Target Pengembalian</th>
              <th width="10%" class="style9 left bottom top  right">Saldo Pokok</th>
        </tr>      
	
		
		
		<!-- Menampilkan data pada tabel -->
            <tr>
              <td height="33" class="style9 top left right"><div align="center" ><?php for($no=1;$no<=$tempo;$no++) {echo "$no<br><br>"; } ?></div></td>
              <td class="style9 top"><div align="center"><?php 
			  //TANGGAL
			  for($noo=1;$noo<=$tempo;$noo++) 
			  {
			  
				$tanggal			 = substr($tglstatus,8,2);
				$bulan  			 = substr($tglstatus,5,2);
				$tahun  			 = substr($tglstatus,0,4);
			  
			  $b=$bulan+$sistem*$noo;
			  
                if ($b>12 and $b<=24){
			  $bl=$b-12;
			  $th=$tahun+1;
			  }else if ($b>24 and $b<=36){
			  $bl=$b-24;
			  $th=$tahun+2;
			  }else if ($b>36 and $b<=48){
			  $bl=$b-36;
			  $th=$tahun+3;
			  }else if ($b>48){
			  $bl=$b-48;
			  $th=$tahun+4;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  

			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
			  echo "$tanggal/$bln/$th<br><br>"; } ?></div></td>
              <td class="style9 left top"><div align="right"><?php	
				for($nu=1;$nu<=$tempo;$nu++) //POKOK
			  {
			  
			  $b=$bulan+$sistem*$nu;
			  $bagi_b=floor($b/12);
			  
			  if ($b>12 ){
			  $bl=$b-(12*$bagi_b);
			  $th=$tahun+$bagi_b;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
				$adaangsurankah=adaangsurankah_anggota("$th-$bln-$tanggal-$id_pinj");
				$wapok		=wajibpokokaja_anggota("$id_pinj");
				
				$sumpok=$wapok*($tempo_pokok-1);
				
				if ($nu<$tempo AND $adaangsurankah==0){
					$pok=number_format($wapok);
			  }elseif ($nu>=$tempo AND $adaangsurankah==0){
					$pok=number_format($alokasi-$sumpok, 0, ',', '.');
			  }else{
				  $pok="0";
			  }
				
			  echo "$pok<br><br>"; } ?>
			  </div></td>
			  
              <td class="style9 left top"><div align="right"><?php for($j=1;$j<=$tempo;$j++) {
			  $jasa=wajibjasaaja_anggota($id_pinj)*$sistem;
			  if($j<=$tempo){
			  $js=$jasa;
			  }else{
			  $js="-";
			  }
			  
			  $saldo=$alokasi-($wapok*($j-1));
			  if ($jenis_jasa==1){$bayar_jasa=$js;}else if ($jenis_jasa==2) {$bayar_jasa=$saldo*($pros_jasa/100);} else{$bayar_jasa=$js;}
			  $bulat_jasa=bulatkan($bayar_jasa);
			  
			  echo "".number_format($bulat_jasa)."<br><br>"; } ?></div></td>
			  
			  
              <td class="style9 left top"><div align="right"><?php 
				
				//KOLOM JUMLAH
				
			  for($s=1;$s<=$tempo;$s++) 
			  {
				   $b=$bulan+$sistem*$s;
			  $bagi_b=floor($b/12);
			  
			  if ($b>12 ){
			  $bl=$b-(12*$bagi_b);
			  $th=$tahun+$bagi_b;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
				$adaangsurankah=adaangsurankah_anggota("$th-$bln-$tanggal-$id_pinj");
				$wapok		=wajibpokokaja_anggota("$id_pinj");
				
				$sumpok=$wapok*($tempo_pokok-1);
				
				if ($s<$tempo AND $adaangsurankah==0){
					$pok=$wapok;
			  }elseif ($s>=$tempo AND $adaangsurankah==0){
					$pok=$alokasi-$sumpok;
			  }else{
				  $pok="0";
			  }
		
			  
			
			  $jasa=wajibjasaaja_anggota($id_pinj)*$sistem;
			  if($s<=$tempo){
			  $js=$jasa;
			  }else{
			  $js="-";
			  }
			  
			  $saldo=$alokasi-($wapok*($s-1));
			  if ($jenis_jasa==1){$bayar_jasa=$js;}else if ($jenis_jasa==2) {$bayar_jasa=$saldo*($pros_jasa/100);} else{$bayar_jasa=$js;}
			  $bulat_jasa=bulatkan($bayar_jasa);
			  
					$sumjasa=$sumjasa+$bulat_jasa;
					
			 
			  
				
				$jumlah=number_format($pok+$bulat_jasa);
			  
			  echo "$jumlah<br><br>";}
			  
			  ?></div></td>
			  
			  <td class="style9 left top"><div align="right"><?php 
				
				//TOTAL TARGET Pengembalian
				
			  for($t=1;$t<=$tempo;$t++) 
			  {
			  
			  
			   $b=$bulan+$sistem*$t;
			  $bagi_b=floor($b/12);
			  
			  if ($b>12 ){
			  $bl=$b-(12*$bagi_b);
			  $th=$tahun+$bagi_b;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
				$adaangsurankah=adaangsurankah_anggota("$th-$bln-$tanggal-$id_pinj");
				$wapok		=wajibpokokaja_anggota("$id_pinj");
				
				$sumpok=$wapok*($tempo_pokok-1);
				
				if ($t<$tempo AND $adaangsurankah==0){
					$pok=$wapok;
			  }elseif ($t>=$tempo AND $adaangsurankah==0){
					$pok=$alokasi-$sumpok;
			  }else{
				  $pok="0";
			  }
					  
		
			  $jasa=wajibjasaaja_anggota($id_pinj)*$sistem;
			  if($t<=$tempo){
			  $js=$jasa;
			  }else{
			  $js="-";
			  }
			  
			  $saldo=$alokasi-($wapok*($t-1));
			  if ($jenis_jasa==1){$bayar_jasa=$js;}else if ($jenis_jasa==2) {$bayar_jasa=$saldo*($pros_jasa/100);} else{$bayar_jasa=$js;}
			  $bulat_jasa=bulatkan($bayar_jasa);
			
			  
			  
				if ($t<$tempo){
							  $tot=$tot+$pok;
							  }else{
							  $tot=$alokasi;
							  }
			  
			  $totjs=$totjs+$bulat_jasa;
			  echo "".number_format($tot+$totjs)."<br><br>";} //Total Target Pengembalian
			  ?></div></td>
			  
			  <td class="style9 left top right"><div align="right"><?php 
			  for($u=1;$u<=$tempo;$u++) 
			  {
				  
				  $b=$bulan+$sistem*$u;
			  $bagi_b=floor($b/12);
			  
			  if ($b>12 ){
			  $bl=$b-(12*$bagi_b);
			  $th=$tahun+$bagi_b;
			  }else{
			  $bl=$b;
			  $th=$tahun;
			  }
			  
				if ($bl<10){
				$bln="0$bl";
				}else{
				$bln=$bl;
				}
				
				$adaangsurankah=adaangsurankah_anggota("$th-$bln-$tanggal-$id_pinj");
				$wapok		=wajibpokokaja_anggota("$id_pinj");
				
				$sumpok=$wapok*($tempo_pokok-1);
				
				if ($u<$tempo AND $adaangsurankah==0){
					$pok=$wapok;
			  }elseif ($u>=$tempo AND $adaangsurankah==0){
					$pok=$alokasi-$sumpok;
			  }else{
				  $pok="0";
			  }
					  
		

			
			  
			  
				if ($u<$tempo){
							  $tota=$tota+$pok;
							  }else{
							  $tota=$alokasi;
							  }
				  

			  $saldo=number_format($alokasi-$tota);

			  echo "$saldo<br><br>";}
			  ?></div></td>
            </tr>
		<!-- Menampilkan Jumlah Total pada tabel -->
		 <tr>	  
          <th width="2%" colspan="2" height="34" class="style9 left bottom top">Total</th>
              <th width="10%" class="style9 left bottom top"><?php echo number_format($alokasi); ?></th>
              <th width="10%" class="style9 left bottom top"><?php echo number_format($sumjasa); ?></th>
              <th width="10%" class="style9 left bottom top"><?php echo number_format($alokasi+($sumjasa)); ?></th>
              <th width="10%" colspan="2" class="style9 left bottom top right">&nbsp;</th>
        </tr> 
</table>
<br>	  
<table width="97%" border="0" align="center" cellpadding="3" cellspacing="0"> 
      <tr>
      <td align="center" colspan="3" class="style9">Menyetujui,</td>
      </tr>
      <tr>
        <td width="50%" height="36" colspan="1" class="style26"><div align="center" class="style9">
          <p><?php echo "$row[sebutan_level_1] <br>$row[nama_lembaga_sort]";?></p>
        </div></td>
        <td width="50%" colspan="2" class="style26"><div align="center" class="style9">
          <p>Pemanfaat</p>
        </div></td>
      </tr>	
	<tr>
	    <th height="24" colspan="-1" class="style9"><p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p><?php echo strtoupper("$ketuaupk[namadepan] $ketuaupk[namabelakang]"); ?></p></th>
        <th colspan="2" class="style9"><p align="center">&nbsp;</p>
        <p align="center">&nbsp;</p>
        <p><?php echo strtoupper($namadepan); ?></p></th>
  </tr>
</table>
<title>5. Rencana Ansuran Individu</title>
<?php } ?>        
</body>
