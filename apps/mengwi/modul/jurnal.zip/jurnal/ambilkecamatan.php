<?php session_start();
include "../../inc/inc.koneksi.php";

$jenis_buku = $_GET['jenis_buku'];
$_SESSION['jenis_buku']	= $jenis_buku;

$row=mysql_fetch_array(mysql_query("select * from jenis_buku WHERE kd_jb='$jenis_buku' WHERE lokasi='$_SESSION[lokasi]' "));

echo "<option>-- Mutasi $row[nama_jb] --</option>
		<option value='$jenis_buku-debit'>Debit</option>
      <option value='$jenis_buku-kredit'>Kredit</option>";

?>
