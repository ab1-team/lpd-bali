<?php session_start(); 
$table_transaksi="transaksi_".$_SESSION['lokasi'];
$table_rekening="rekening_".$_SESSION['lokasi'];

?>
<script type="text/javascript">	
	$(function(){
			function pageLoad(){
				$('[data-toggle=tooltip]').tooltip();
			}
			pageLoad();
			SingApp.onPageLoad(pageLoad);
		});
	
	function deleteRow(ID) {
		var idt	= ID;
	   var pilih = confirm('Dengan menghapus jurnal '+idt+ ' secara otomatis jurnal yang berkaitan juga akan terhapus?');
		if (pilih==true) {
			$.ajax({
				type	: "POST",
				url		: "modul/jurnal/hapus.php",
				data	: "idt="+idt,
				success	: function(data){
					$("#TampilJurnal").load('modul/jurnal/tampil_jurnal.php');
					alert('Berhasil!');
				}
			});
		}
	}
</script>

				<div class="alert alert-info animated fadeInDown hidden-print">
					<legend><i class="fa fa-check"></i> Posting Jurnal Transaksi Terakhir!</legend>
					<div class="table-responsive">
                    <table id="datatable-table" class="table table-hover">
                        <thead class="bg-info text-white">
                        <tr>
                            <th>Tgl</th>
                            <th>NoRek</th>
							<th>Nama Rekening</th>
                            <th>Debit</th>
                            <th>Kredit</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
						ini_set('display_errors', 1); ini_set('error_reporting', E_ERROR);
						include "../../inc/inc.koneksi.php";
						$idt=mysql_fetch_array(mysql_query("SELECT max(idt) FROM $table_transaksi ORDER BY idt DESC"));
						$maxtrans=$idt[0];
			
						$kredit=mysql_fetch_array(mysql_query("select * from $table_transaksi t, $table_rekening r, jenis_buku jb where jb.kd_jb=r.kd_jb AND r.kd_rekening=t.rekening_kredit AND t.idt='$maxtrans' AND jb.lokasi='0' AND jb.kecuali NOT LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi]%' OR jb.kd_jb=r.kd_jb AND r.kd_rekening=t.rekening_kredit AND t.idt='$maxtrans' AND jb.lokasi LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi]%' "));
						echo "
						<tr>
							<td>$kredit[tgl_transaksi]</td>
							<td><a href='' data-toggle='tooltip' data-placement='left' title='$kredit[nama_rekening]'>$kredit[rekening_kredit]</a></td>
							<td><strong>$kredit[nama_jb] ($kredit[ins])</strong> <i class='glyphicon glyphicon-arrow-right'></i> <br> $kredit[nama_rekening] <br> <i>$kredit[keterangan_transaksi]</i></td>
							<td>0</td>
							<td>".number_format($kredit['jumlah'])."</td>
                        </tr> ";
						
						$debit=mysql_fetch_array(mysql_query("select * from $table_transaksi t, $table_rekening r, jenis_buku jb where jb.kd_jb=r.kd_jb AND r.pasangan=t.rekening_kredit AND t.idt='$maxtrans' AND jb.lokasi='0' AND jb.kecuali NOT LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi]%' OR jb.kd_jb=r.kd_jb AND r.pasangan=t.rekening_kredit AND t.idt='$maxtrans' AND jb.lokasi LIKE '%$_SESSION[kd_kab]-$_SESSION[lokasi]%' "));
						echo "
						<tr>
							<td>$debit[tgl_transaksi]</td>
							<td><a href='' data-toggle='tooltip' data-placement='left' title='$debit[nama_rekening]'>$debit[rekening_debit]</a></td>
							<td><strong>$debit[nama_jb] ($debit[ins])</strong> <i class='glyphicon glyphicon-arrow-left'></i> <br> $debit[nama_rekening] <br> <i>$debit[keterangan_transaksi]</i></td>
							<td>".number_format($debit['jumlah'])."</td>
							<td>0</td>
                        </tr>";
						  ?>
                        </tbody>
                    </table>
                </div>
				<p class="fs-sm"><i class="glyphicon glyphicon-comment"></i> Posting Jurnal transaksi ini dilakukan otomatis oleh sistem! | 
				
				<a href="javascript:;" data-toggle='tooltip' data-placement='top' title='Printer Dot Matrik 1' onclick="MM_openBrWindow('modul/jurnal/c_kw_dot_1.php?idt=<?php echo $kredit['idt'];?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"><i class="glyphicon glyphicon-print hidden-print"></i> Kwitansi 1</a> |
				<a href="javascript:;" data-toggle='tooltip' data-placement='top' title='Printer Dot Matrik 2' onclick="MM_openBrWindow('modul/jurnal/c_kw_dot_2.php?idt=<?php echo $kredit['idt'];?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"><i class="glyphicon glyphicon-print hidden-print"></i> Kwitansi 2</a> |
				<a href="javascript:;" data-toggle='tooltip' data-placement='top' title='Printer Biasa' onclick="MM_openBrWindow('modul/jurnal/c_kw.php?idt=<?php echo $kredit['idt'];?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"><i class="glyphicon glyphicon-print hidden-print"></i> Kwitansi 3</a>
							
				<?php
				if($_SESSION['level']==1 AND $_SESSION['jabatan']==1) {$tombol="javascript:deleteRow(\"{$kredit[idt]}\")"; $title="Dengan menghapus $kredit[nama_rekening] transaksi yang berkaitan akan otomatis terhapus";}
								else{$tombol="#"; $title="Hapus jurnal transaksi hanya dapat dilakukan oleh Ketua UPK/Manajer";}
				echo "
				<a class='pull-right fs-larger' href='$tombol' data-toggle='tooltip' data-placement='left' title='$title'><i class='fa fa-eraser'></i> Hapus</a> 
						";
				?>
				</p>
				</div>