
<script type="text/javascript">
<![CDATA[
var htmlobjek;
$(document).ready(function(){
  //apabila terjadi event onchange terhadap object <select id=jenis_rekening>
  $("#jenis_rekening").change(function(){
    var jenis_rekening = $("#jenis_rekening").val();
    $.ajax({
        url: "modul/jurnal/ambilkota.php",
        data: "jenis_rekening="+jenis_rekening,
        cache: false,
        success: function(msg){
            //jika data sukses diambil dari server kita tampilkan
            //di <select id=jenis_buku>
            $("#jenis_buku").html(msg);
        }
    });
  });
  $("#jenis_buku").change(function(){
    var jenis_buku = $("#jenis_buku").val();
    $.ajax({
        url: "modul/jurnal/ambilkecamatan.php",
        data: "jenis_buku="+jenis_buku,
        cache: false,
        success: function(msg){
            $("#jenis_mutasi").html(msg);
			$("#TampilBuku").load('modul/jurnal/tampil_buku.php');
			$("#TampilSaldo").load('modul/jurnal/tampil_saldo.php');
        }
    });
  });

  $("#jenis_mutasi").change(function(){
		var jenis_mutasi = $("#jenis_mutasi").val();
    $.ajax({
        url: "modul/jurnal/ambilkelurahan.php",
        data: "jenis_mutasi="+jenis_mutasi,
        cache: false,
        success: function(msg){
            $("#rekening").html(msg);
        }
    });
  });
  
  
					  
				
$("#TampilJurnal").load('modul/jurnal/tampil_jurnal.php');
$("#FormNominal").load('modul/jurnal/form_nominal.php');
$("#TampilBuku").load('modul/jurnal/tampil_buku.php');
$("#TampilSaldo").load('modul/jurnal/tampil_saldo.php');
				
				
				$("#rekening").change(function(){
						var cari = $("#rekening").val();
						var tgl_transaksi = $("#tgl_transaksi").val();
						carirekening(cari);
					})
					function carirekening(e){
						var cari = e;
						if(cari==112.01 || cari==112.02 || cari==112.03 || cari==113.01 || cari==113.02 || cari==113.03 || cari==131.02 || cari==132.02 || cari==115.01 || cari==115.02 || cari==115.03){
							$("#FormNominal").load('modul/jurnal/dilarang_angsuran.php');
						}else if(cari==112.07 || cari==113.07 || cari==131.01 || cari==131.03 || cari==132.01 || cari==132.03 || cari==122.07 || cari==123.07){
							$("#FormNominal").load('modul/jurnal/dilarang_pencairan.php');
						}else if(cari==111.28 || cari==513.01 || cari==111.30 || cari==215.02){
							$("#FormNominal").load('modul/jurnal/dilarang_penghapusan.php');
						}else if(cari==111.21 || cari==151.01 || cari==111.20 || cari==141.01 || cari==111.22 || cari==161.01){
						
						if(cari.length==0){ $("#rekening").focus(); return false; }
						
								$.ajax({
									type	: "POST",
									url		: "modul/jurnal/form_inventaris.php",
									data	: "cari="+cari+
												"&tgl_transaksi="+tgl_transaksi,
									success	: function(data){
										$("#FormNominal").html(data);
									}
								});
						
						}else{
						$.ajax({
							type	: "POST",
							url		: "modul/jurnal/form_nominal.php",
							data	: "cari="+cari+
										"&tgl_transaksi="+tgl_transaksi,
							success	: function(data){
								$("#FormNominal").html(data);
							}
						});
						
						}
					}
				

				
});

 ]]>

</script>

  
	
		<div class="row">
		
            <div class="col-md-5 col-md-offset hidden-print">
                <section class="widget">
									<legend>Form Transaksi Umum</legend>
                    <div class="widget-body">
                        <div id="validation-form" class="form-horizontal form-label-left" method="post"
                              data-parsley-priority-enabled="false"
                              novalidate="novalidate">
                            <fieldset>
								<div class="form-group">
                                    <label class="col-sm-4 control-label" for="default-select">Jenis Buku</label>
                                    <div class="col-sm-8">
                                        <select id="jenis_rekening"  name="jenis_rekening"
                                                data-placeholder="-- Pilih Jenis Buku --"
                                                data-width="auto"
                                                data-minimum-results-for-search="10"
                                                tabindex="-1"
												class="select2 form-control">
												<option value=""></option>
													<?php 
													$view=mysql_query("select * from rekening_riil"); //Buku Kecil
														while($row=mysql_fetch_array($view)){
														echo "<option value='$row[kd_rr]'>$row[nama_rr]</option>";
														} ?>
										</select>
									</div>
                                </div>
								<div class="form-group">
                                    <label class="col-sm-4 control-label" for="default-select">Jenis Sub Buku</label>
                                    <div class="col-sm-8">
                                        <select id="jenis_buku"  name="jenis_buku"
                                                data-placeholder="-- Pilih Jenis Sub Buku --"
                                                data-width="auto"
                                                data-minimum-results-for-search="10"
                                                tabindex="-1"
												class="select2 form-control">
												<option value=""></option>
										</select>
									</div>
                                </div>
								<div class="form-group">
                                    <label class="col-sm-4 control-label" for="default-select">Jenis Mutasi</label>
                                    <div class="col-sm-8">
                                        <select id="jenis_mutasi"  name="jenis_mutasi"
                                                data-placeholder="-- Pilih Jenis Mutasi --"
                                                data-width="auto"
                                                data-minimum-results-for-search="10"
                                                tabindex="-1"
												class="select2 form-control">
												<option value=""></option>
										</select>
									</div>
                                </div>
								<div class="form-group">
                                    <label class="col-sm-4 control-label" for="default-select">Nama Rekening</label>
                                    <div class="col-sm-8">
                                        <select id="rekening"  name="rekening"
                                                data-placeholder="-- Pilih Nama Rekening --"
                                                data-width="auto"
                                                data-minimum-results-for-search="10"
                                                tabindex="-1"
												class="select2 form-control">
												<option value=""></option>
										</select>
									</div>
                                </div>
								
								<div class="form-group">
									<label class="control-label col-sm-4">Tanggal</label>
									<div class="col-sm-8"><input type="text" name="tgl_transaksi" id="tgl_transaksi" class="form-control" 
										value="<?php echo date('Y-m-d');?>" required="required" autocomplete="off" placeholder="-- Tanggal Transaksi --"> </div>
								</div>
							
							
								<div id="FormNominal"></div>
                            </fieldset>
                                
                        </div>
                    </div>
                </section>
            </div>
			
			<div class="col-md-7">
				<h1 class="page-title hidden-print"><span class="fw-semi-bold">Transaksi Jurnal Umum</span></h1>
				<legend class="mt-n-sm">Jurnal umum ini dapat digunakan untuk semua transaksi kecuali Transaksi Angsuran dan Pencairan</legend>
				<legend><div id="TampilJurnal"></div></legend>
				 <div id="TampilSaldo"></div>
			</div>
			
	
	
	<div class="col-md-12">
            <div id="TampilBuku"></div>
	</div>		
	
</div>