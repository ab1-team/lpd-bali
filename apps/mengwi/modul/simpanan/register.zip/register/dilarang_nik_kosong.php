<div class="alert alert-danger mt animated fadeInDown">
	<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
    <span class="create-server-name"></span><i class="fa fa-warning"></i> <strong>Perhatian!</strong><br>
	NIK tidak boleh kosong, silahkan isi NIK sesuai dengan data.
</div>