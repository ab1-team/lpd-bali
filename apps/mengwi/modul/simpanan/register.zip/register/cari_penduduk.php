<?php session_start(); 	?>

<script type="text/javascript">

function MM_openBrWindow(theURL,winName,features) { //membuka window untuk print
				window.open(theURL,winName,features);
				}
					
	$(document).ready(function() {
		
$("#TampilSimpanan").load('modul/simpanan/tampil_simpanan.php');
		
		//apabila terjadi event onchange terhadap object <select id=jenis_kegiatan>
  $("#jenis_kegiatan").change(function(){
    var jenis_kegiatan = $("#jenis_kegiatan").val();
    $.ajax({
        url: "modul/simpanan/register/ambil_nama_usaha.php",
        data: "jenis_kegiatan="+jenis_kegiatan,
        cache: false,
        success: function(msg){
            //jika data sukses diambil dari server kita tampilkan
            //di <select id=jenis_buku>
            $("#usaha").html(msg);
        }
    });
  });
  
  
  <?php
  if ($_POST['nik']>=16){
  ?>
  $("#namadepan").focus();
  <?php } ?>
				
		$("#hp").keypress(function (data)  { if(data.which!=8 && data.which!=0 && (data.which<48 || data.which>57)){ return false; } });
		$("#kk").keypress(function (data)  { if(data.which!=8 && data.which!=0 && (data.which<48 || data.which>57)){ return false; } });

                $("#SimpanPenduduk").click(function() {
                    var nik			= $('#nik').val();
					var namadepan	= $('#namadepan').val();
					var jk			= $('#jk').val();
					var tempat_lahir= $('#tempat_lahir').val();
					var tgl_lahir	= $('#tgl_lahir').val();
					var desaa		= $('#desaa').val();
					var alamat		= $('#alamat').val();
					var hp			= $('#hp').val();
					var kk			= $('#kk').val();
					var nik_penjamin= $('#nik_penjamin').val();
					var penjamin	= $('#penjamin').val();
					var hubungan	= $('#hubungan').val();
					var usaha		= $('#usaha').val();
					var jenis_jaminan= $('#jenis_jaminan').val();
					var nomor_milik	= $('#nomor_milik').val();
					var merk		= $('#merk').val();
					var alamat_jaminan		= $('#alamat_jaminan').val();
					var nilai_jaminan		= $('#nilai_jaminan').val();
					var uname		= $('#uname').val();
					var pass		= $('#pass').val();
					var foto		= $('#foto').val();
					
						if(nik.length==0){ $("#konfirmasi").load('modul/simpanan/register/dilarang_nik_kosong.php');
						$("#nik").focus();
						return false;
							}

						if(nik.length<16){ $("#konfirmasi").load('modul/simpanan/register/dilarang_nik.php');
						$("#nik").focus();
						return false;
							}
						if(namadepan.length==0){ $("#konfirmasi").load('modul/simpanan/register/dilarang_kosong.php');
						$("#namadepan").focus();
						return false;
							}
							
						if(hp.length==0){ $("#konfirmasi").load('modul/simpanan/register/dilarang_hp_kosong.php');
						$("#hp").focus();
						return false;
							}
						
							
						if(desaa.length==0){ $("#konfirmasi").load('modul/simpanan/register/dilarang_kosong.php');
						$("#desaa").focus();
						return false;
							}	
							
                    $.ajax({
                        type: "POST",
                        url: "modul/simpanan/register/simpan.php",
                        data: 	"nik="+nik+
								"&namadepan="+namadepan+
								"&jk="+jk+
								"&tempat_lahir="+tempat_lahir+
								"&tgl_lahir="+tgl_lahir+
								"&desaa="+desaa+
								"&alamat="+alamat+
								"&hp="+hp+
								"&kk="+kk+
								"&nik_penjamin="+nik_penjamin+
								"&penjamin="+penjamin+
								"&hubungan="+hubungan+
								"&usaha="+usaha+
								"&jenis_jaminan="+jenis_jaminan+
								"&nomor_milik="+nomor_milik+
								"&merk="+merk+
								"&alamat_jaminan="+alamat_jaminan+
								"&nilai_jaminan="+nilai_jaminan+
								"&uname="+uname+
								"&pass="+pass+
								"&foto="+foto,
                        
						success: function(data) {
							
							//$("#form_register").load('modul/simpanan/register/cari_penduduk.php');
							
							$("#konfirmasi").load('modul/simpanan/register/sukses_registrasi.php');
							
							$("#nik").keyup();
								//return false;
									

                        }
                    });

                });
				
				$("#MySimpananUmum").click(function(){
						var nik = $("#MySimpananUmum").val();
						var ids = 1;
						
						$.ajax({
							type	: "POST",
							url		: "modul/simpanan/input_simpanan_individu.php",
							data	: "ids="+ids+
										"&nik="+nik,
							success	: function(data){
								$("#FormSimpananUmum").html(data);
							}
						});
					});
					
			$("#SimpanNewAnggota").click(function() {
                    var nik				= $('#nik').val();
                    var tgl_transaksi	= $('#tgl_transaksi').val();
                    var rek_anggota		= $('#rek_anggota').val();
                    var simpok			= $('#simpok').val();
                    var simjib			= $('#simjib').val();
                    var simsuka			= $('#simsuka').val();
							
                    $.ajax({
                        type: "POST",
                        url: "modul/simpanan/register/simpan_new_anggota.php",
                        data: 	"nik="+nik+
								"&tgl_transaksi="+tgl_transaksi+
								"&rek_anggota="+rek_anggota+
								"&simpok="+simpok+
								"&simjib="+simjib+
								"&simsuka="+simsuka,
                        
						success: function(data) {
							$("#suksessna").load('modul/simpanan/register/sukses_anggota.php');
							
                        }
                    });

                });
				
				
				$("#MutasiAntarKec").click(function(){
						var cari = $("#MutasiAntarKec").val();
						
						$.ajax({
							type	: "POST",
							url		: "modul/simpanan/register/form_mutasi.php",
							data	: "cari="+cari,
							success	: function(data){
								$("#FormMutasi").html(data);
							}
						});
					});
					
				$("#ProposalPeternakan").click(function(){
						var nik = $("#ProposalPeternakan").val();
						
						$.ajax({
							type	: "POST",
							url		: "modul/pinjaman/register/input_pinjaman_peternakan.php",
							data	: "nik="+nik,
							success	: function(data){
								$("#FormProposalPeternakan").html(data);
							}
						});
					});
				
				$("#ProposalIndividu").click(function(){
						var nik = $("#ProposalIndividu").val();
						
						$.ajax({
							type	: "POST",
							url		: "modul/pinjaman/register/input_pinjaman_individu.php",
							data	: "nik="+nik,
							success	: function(data){
								$("#FormProposalIndividu").html(data);
							}
						});
					});
					
					
				$("#ProposalKelompok").click(function(){
						var nik = $("#ProposalIndividu").val();
						
						$.ajax({
							type	: "POST",
							url		: "modul/pinjaman/register/input_pinjaman_ke_kelompok.php",
							data	: "nik="+nik,
							success	: function(data){
								$("#FormProposalKelompok").html(data);
							}
						});
					});
					
				
				
            });
        </script>
		
<?php
include "../../../inc/inc.koneksi.php";
include "../../../inc/fungsi_indotgl.php";
ini_set('display_errors', 1); ini_set('error_reporting', E_ERROR);
$table	= "anggota_$_SESSION[kd_kab]";
$id	= $_POST['nik'];
$text	= "SELECT *
			FROM $table WHERE nik= '$id'";
$sql 	= mysql_query($text);
$row	= mysql_num_rows($sql);
if ($row>0 AND $id>=16){
	$r=mysql_fetch_array($sql);
	$_SESSION['nia'] = $r['id'];
	$desa=mysql_fetch_array(mysql_query("select * from kecamatan c, desa d WHERE c.kd_kec=d.kd_kec AND d.id='$r[desa]' ")); 
	$pek=mysql_fetch_array(mysql_query("select * from jenis_kegiatan k, usaha u WHERE k.id=u.jenis_kegiatan AND u.id='$r[usaha]' order by u.nama_usaha "));
	$hub=mysql_fetch_array(mysql_query("select * from keluarga WHERE id='$r[hubungan]' ")); 
	$jaminan 		= explode(",", $r['jaminan']);
	$jj=mysql_fetch_array(mysql_query("select * from jenis_jaminan WHERE id='$jaminan[0]' ")); 
													
	$nik			=$r['nik'];
	$nianggota		=$r['id'];
	$namadepan		=$r['namadepan'];
	$jk				=$r['jk'];
	$tempat_lahir	=$r['tempat_lahir'];
	$tgl_lahir		=$r['tgl_lahir'];
	$alamat			=$r['alamat'];
	$desaa			=$desa['nama_desa'];
	$kd_kec			=$desa['kd_kec'];
	$hp				=$r['hp'];
	$kk				=$r['kk'];
	$usaha			=$pek['nama_usaha'];
	$id_usaha		=$pek['id'];
	$id_kegiatan	=$pek['id_kegiatan'];
	$jenis_kegiatan	=$pek['deskripsi_jk'];
	$foto			=$r['foto'];
	$nik_penjamin	=$r['nik_penjamin'];
	$penjamin		=$r['penjamin'];
	$id_hubungan	=$hub['id'];
	$hubungan		=$hub['kekeluargaan'];
	
	$jenis_jaminan	=$jj['nama_jaminan'];
	$nomor_milik	=$jaminan[1];
	$merk			=$jaminan[2];
	$alamat_jaminan	=$jaminan[3];
	$nilai_jaminan	=$jaminan[4];
	$uname			=$r['uname'];
	$pass			=$r['pass'];
	$ket			="&nbsp;<br>&nbsp;";
	
}else{
	$kec=mysql_fetch_array(mysql_query("select * from kabupaten b, kecamatan c WHERE b.id=c.kd_kab AND c.id='$_SESSION[lokasi]' ")); 
	$tgl	=substr($id,6,2);
	$bln	=substr($id,8,2);
	$thn	=substr($id,10,2);
	if($tgl>=40){$tg=$tgl-40;}else{$tg=$tgl;}
	$nik			="";
	$nianggota		="";
	$namadepan		="";
	$jk				="P";
	$tempat_lahir	=$kec['nama_kab'];
	$tgl_lahir		="19$thn-$bln-$tg";
	$alamat			="";
	$desaa			="-- Silahkan Pilih Desa/Kelurahan --";
	$kd_kec			=$kec['kd_kec'];
	$hp				="08";
	$kk				="";
	$id_kegiatan	="4";
	$jenis_kegiatan	="Pertanian";
	$id_usaha		="22";
	$usaha			="Tani";
	$foto			="";
	$nik_penjamin	="";
	$penjamin		="";
	$id_hubungan	="1";
	$hubungan		="Suami";
	$jenis_jaminan	="-- Silahkan Pilih Jenis Jaminan --";
	$nomor_milik	="";
	$merk			="";
	$alamat_jaminan	="";
	$nilai_jaminan	="";
	$uname			=$id;
	$pass			=date('Y').substr($id,14,2);
	$ket			="* Silahkan lengkapi Data Dibawah ini, kemudian klik tombol SIMPAN DATA :<br>&nbsp;";
}
?>
	<div class="col-sm-7">
		<?php echo "<div class='text-danger'>$ket</div>";?>
	
		<!-- PROPOSAL KELOMPOK -->
			
			<div class="panel-group mb-lg" id="accordionKelompok" data-toggle="collapse">
								<div class="panel panel-default">
									<div id="collapseKelompok" class="panel-collapse collapse">
										<div class="panel-body">
											<?php
												$sqlmut=mysql_query("select * from pinjaman_anggota_$_SESSION[kd_kab] where nia='$r[id]' AND `status`='P' OR nia='$r[id]' AND `status`='V' OR nia='$r[id]' AND `status`='W' OR nia='$r[id]' AND `status`='M' ");
												$lacakmut	= mysql_num_rows($sqlmut);
												$sqlkk=mysql_query("select * from anggota_$_SESSION[kd_kab] a, pinjaman_anggota_$_SESSION[kd_kab] pa where a.id=pa.nia AND a.kk='$r[kk]' AND a.kk!='0' AND a.kk!='' ");
												$lacak_kk	= mysql_num_rows($sqlkk);
													if ($lacakmut>0){
														$pa=mysql_fetch_array($sqlmut);
														echo "
														<div class='alert alert-danger mt animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> <strong>Perhatian</strong> 
															<br>YBS terdeteksi memiliki pinjaman ($pa[jenis_pinjaman]) sebesar ".number_format($pa['alokasi'])." dengan status $pa[status]
														</div>
														";
													}else if ($lacak_kk>0){
														$rkk=mysql_fetch_array($sqlkk);
														if($rkk['jenis_pinjaman']=="K"){$jp="Kelompok";}else{$jp="Individu";}
														echo "
														<div class='alert alert-danger mt animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> 
															<strong>Perhatian</strong> <br>
															Nomor KK <b>$r[kk]</b> telah memiliki Pinjaman $jp a.n. <b>".strtoupper($rkk['namadepan'])."</b> NIK. $rkk[nik] Loan ID.$rkk[id] Status $rkk[status]
														</div>";
													}else{
														echo "<div id='FormProposalKelompok'></div>";
													}
											?>
											
										</div>
									</div>
								</div>
							</div>
							
							
		<!-- PROPOSAL INDIVIDU -->		
			<div class="panel-group" id="accordionIndividu" data-toggle="collapse">
								<div class="panel panel-default">
									<div id="collapseIndividu" class="panel-collapse collapse">
										<div class="panel-body">
											<?php
												$sqlmut=mysql_query("select * from pinjaman_anggota_$_SESSION[kd_kab] where nia='$r[id]' AND `status`='P' OR nia='$r[id]' AND `status`='V' OR nia='$r[id]' AND `status`='W' OR nia='$r[id]' AND `status`='M' ");
												$lacakmut	= mysql_num_rows($sqlmut);
												$sqlkk=mysql_query("select * from anggota_$_SESSION[kd_kab] a, pinjaman_anggota_$_SESSION[kd_kab] pa where a.id=pa.nia AND a.kk='$r[kk]' AND a.kk!='0' AND a.kk!='' AND pa.status!='L' AND pa.status!='R' ");
												$lacak_kk	= mysql_num_rows($sqlkk);
													if ($lacakmut>0){
														$pa=mysql_fetch_array($sqlmut);
														echo "
														<div class='alert alert-danger mt animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> <strong>Perhatian</strong> 
															<br>YBS terdeteksi memiliki pinjaman ($pa[jenis_pinjaman]) sebesar ".number_format($pa['alokasi'])." dengan status $pa[status]
														</div>
														";
													}else if ($lacak_kk>0){
														$rkk=mysql_fetch_array($sqlkk);
														if($rkk['jenis_pinjaman']=="K"){$jp="Kelompok";}else{$jp="Individu";}
														echo "
														<div class='alert alert-danger mt animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> 
															<strong>Perhatian</strong> <br>
															Nomor KK <b>$r[kk]</b> telah memiliki Pinjaman $jp a.n. <b>".strtoupper($rkk['namadepan'])."</b> NIK. $rkk[nik] Loan ID.$rkk[id] Status $rkk[status]
														</div>";
													}else{
														echo "<div id='FormProposalIndividu'></div>";
													}
					?>
										</div>
									</div>
								</div>
							</div>
							
			<!-- PROPOSAL PETERNAKAN -->		
			<div class="panel-group" id="accordionPeternakan" data-toggle="collapse">
								<div class="panel panel-default">
									<div id="collapsePeternakan" class="panel-collapse collapse">
										<div class="panel-body">
											<?php
												$sqlmut=mysql_query("select * from pinjaman_anggota_$_SESSION[kd_kab] where nia='$r[id]' AND `status`='P' OR nia='$r[id]' AND `status`='V' OR nia='$r[id]' AND `status`='W' OR nia='$r[id]' AND `status`='M' ");
												$lacakmut	= mysql_num_rows($sqlmut);
													if ($lacakmut>0){
														$pa=mysql_fetch_array($sqlmut);
														echo "
														<div class='alert alert-danger animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> <strong>Perhatian</strong> 
															<br>YBS terdeteksi memiliki pinjaman ($pa[jenis_pinjaman]) sebesar ".number_format($pa['alokasi'])." dengan status $pa[status]
														</div>
														";
													}else{
														echo "<div id='FormProposalPeternakan'></div>";
													}
					?>
										</div>
									</div>
								</div>
							</div>
							
							<!-- MUTASI -->
			
			<div class="panel-group" id="accordionMutasi" data-toggle="collapse">
								<div class="panel panel-default">
									<div id="collapseMutasi" class="panel-collapse collapse">
										<div class="panel-body">
											<?php
												$sqlmut=mysql_query("select * from pinjaman_anggota_$_SESSION[kd_kab] where nia='$r[id]' AND status!='L' ");
												$lacakmut	= mysql_num_rows($sqlmut);
													if ($lacakmut>0){
														echo "
														<div class='alert alert-info mt animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> <strong>Anda tidak dapat Mutasi</strong> 
															<br>YBS memiliki proposal/pinjaman aktif
														</div>
														";
													}else{
														echo "<div id='FormMutasi'></div>";
													}
					?>
										</div>
									</div>
								</div>
							</div>
							
							
							
	<div class="panel-group mb-lg" id="accordion2" data-toggle="collapse">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion2" href="#collapseOne2" style="text-decoration:none; font-weight: bold">
                                    1. IDENTITAS PENDUDUK
                                    <i class="fa fa-angle-down pull-right"></i>
                                </a>
                            </h5>
                        </div>
                        <div id="collapseOne2" class="panel-collapse collapse in">
                            <div class="panel-body" style='background-color:#f8f8f8;'>
                                <input type="hidden" name="nik" id="nik" value="<?php echo $nik; ?>"/>
									<div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">N I A</label>
										<div class="col-sm-8">
												<input type="text" name="" value="<?php echo $nianggota;?>" id="" class="form-control" 
														required="required" autocomplete="off" placeholder="" disabled />
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">Nama Lengkap</label>
										<div class="col-sm-8">
												<input type="text" name="namadepan" value="<?php echo $namadepan;?>" id="namadepan" class="form-control" 
														required="required" autocomplete="off" placeholder="Nama Lengkap"/>
										</div>
									</div>
									<div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">Jenis Kelamin</label>
										<div class="col-sm-3">
												<select class="select2 form-control" tabindex="-1" data-width="auto"
                                                data-minimum-results-for-search="10"
															 name="jk" id="jk">
                                                        <option value="<?php echo $jk;?>"><?php echo $jk;?></option>
                                                        <option value="P">Perempuan</option>
                                                        <option value="L">Laki-laki</option>
													</select>
										</div>
										
									</div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Tempat / Tgl Lahir</label>
                                        <div class="col-sm-4"><input type="text" value="<?php echo $tempat_lahir;?>" name="tempat_lahir" id="tempat_lahir" class="form-control" 
										required="required" autocomplete="off" placeholder="Tempat Lahir"></div>
										
										<div class="col-sm-4"><input type="text" value="<?php echo $tgl_lahir;?>"  name="tgl_lahir" id="tgl_lahir" class="form-control" 
										required="required" autocomplete="off" placeholder="Tgl (YYYY-MM-DD)"> </div>
                                    </div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Alamat KTP</label>
                                        <div class="col-sm-8"><input type="text" value="<?php echo $alamat;?>" name="alamat" id="alamat" maxlength="50" class="form-control" 
										required="required" autocomplete="off" placeholder="Dusun/Jalan/Kampung/RT/RW"> </div>
                                    </div>
									
														<div class="form-group">
															<label class="col-sm-4 control-label">Desa/Kelurahan</label>
															<div class="col-sm-8">
																<select name="desaa" id="desaa" class="select2 form-control">
																	<?php 
																	echo "<option value='$desa[id]'>$desaa</option>";
																	$view=mysql_query("select * from desa where kd_kec='$kd_kec' order by kd_desa asc"); //DESA
																		while($row=mysql_fetch_array($view)){
																		echo "<option value='$row[id]'>$row[nama_desa]</option>";
																		}
																	?>
																</select>
															</div>
														</div>
									 
									<div class="form-group">
                                        <label class="control-label col-sm-4">Nomor HP</label>
                                        <div class="col-sm-8"><input type="text" value="<?php echo $hp;?>" name="hp"  maxlength="14" class="form-control" id="hp"
										required="required" autocomplete="off" placeholder="Nomor Handphone"> </div>
                                    </div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Nomor KK</label>
                                        <div class="col-sm-8"><input type="text" value="<?php echo $kk;?>" name="kk"  maxlength="16" class="form-control" id="kk"
										required="required" autocomplete="off" placeholder="Nomor Kartu Keluarga"> </div>
                                    </div>
									<div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">Jenis Kegiatan / Usaha</label>
										<div class="col-sm-4">
											<select id="jenis_kegiatan"  name="jenis_kegiatan"
												data-placeholder="-- Pilih Jenis Kegiatan --"
												data-width="auto"
												data-minimum-results-for-search="10"
												tabindex="-1"
												class="select2 form-control">
												<?php 
												echo "<option value='$id_kegiatan'>$jenis_kegiatan</option>";
												$view=mysql_query("select * from jenis_kegiatan ORDER BY id"); //jenis kegiatan
												while($row=mysql_fetch_array($view)){
												echo "<option value='$row[id]'>$row[deskripsi_jk]</option>";
												} ?>
											</select>
										</div>
										<div class="col-sm-4">
											<select id="usaha" name="usaha" class="form-control" data-placeholder="-- Pilh Nama Usaha --"
                                                            data-width="auto">
                                                        <?php 
														echo "<option value='$id_usaha'>$usaha</option>";
													 ?>
													</select>
										</div>
									</div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Link Foto</label>
                                        <div class="col-sm-8"><input type="text" name="foto" class="form-control" id="foto" value="<?php echo $foto;?>"
										required="required" autocomplete="off" placeholder="-- Gunakan link dari Google Foto, Facebook, Google Drive, dll --"> <br>Klik kanan foto, kemudian Copy Image Location</div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading collapsed">
                            <h5 class="panel-title">
                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo2" style="text-decoration:none; font-weight: bold">
                                    2. IDENTITAS PENJAMIN
                                    <i class="fa fa-angle-down pull-right"></i>
                                </a>
                            </h5>
                        </div>
                        <div id="collapseTwo2" class="panel-collapse collapse">
                            <div class="panel-body" style='background-color:#f8f8f8;'>
                                <div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">NIK Penjamin</label>
										<div class="col-sm-8">
												<input type="text" value="<?php echo $nik_penjamin;?>" name="nik_penjamin" id="nik_penjamin" class="form-control" 
														required="required" autocomplete="off" placeholder="NIK Penjamin">
										</div>
								</div>
								<div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">Nama Lengkap</label>
										<div class="col-sm-8">
												<input type="text" value="<?php echo $penjamin;?>" name="penjamin" id="penjamin" class="form-control" 
														required="required" autocomplete="off" placeholder="Nama Keluarga Penjamin">
										</div>
								</div>
								<div class="form-group">
										<label class="col-sm-4 control-label" for="appended-input">Hubungan</label>
										<div class="col-sm-8">
											<select id="hubungan" name="hubungan" class="form-control"
                                                            data-width="auto">
                                                        <?php
													echo "<option value='$id_hubungan'>$hubungan</option>";
													$data=mysql_query("select * from keluarga order by id asc"); //KELUARGA
														while($rows=mysql_fetch_array($data)){
														echo "<option value='$rows[id]'>$rows[kekeluargaan]</option>";
														} ?>
													</select>
										</div>
								</div>
							</div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree2" style="text-decoration:none; font-weight: bold">
                                    3. IDENTITAS JAMINAN
                                    <i class="fa fa-angle-down pull-right"></i>
                                </a>
                            </h5>
                        </div>
                        <div id="collapseThree2" class="panel-collapse collapse">
                            <div class="panel-body" style='background-color:#f8f8f8;'>
									<div class="form-group">
                                        <label class="col-sm-4 control-label" for="appended-input">Jenis Jaminan</label>
										<div class="col-sm-8">
											<select id="jenis_jaminan" name="jenis_jaminan" class="form-control"
                                                            data-width="auto">
                                                        <?php
													echo "<option value='$jj[id]'>$jenis_jaminan</option>";
													$data=mysql_query("select * from jenis_jaminan order by id asc"); //KELUARGA
														while($rows=mysql_fetch_array($data)){
														echo "<option value='$rows[id]'>$rows[nama_jaminan]</option>";
														} ?>
													</select>
										</div>
                                    </div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Nomor Kepemilikan</label>
                                        <div class="col-sm-8"><input type="text" name="nomor_milik" class="form-control" id="nomor_milik" value="<?php echo $nomor_milik;?>"
										required="required" autocomplete="off" placeholder="Nomor Bukti Kepemilikan"> </div>
                                    </div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Merk / Type</label>
                                        <div class="col-sm-8"><input type="text" name="merk" class="form-control" id="merk" value="<?php echo $merk;?>"
										required="required" autocomplete="off" placeholder="Merk / Type"> </div>
                                    </div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Alamat/Lokasi Jaminan</label>
                                        <div class="col-sm-8"><input type="text" name="alamat_jaminan" class="form-control" id="alamat_jaminan" value="<?php echo $alamat_jaminan;?>"
										required="required" autocomplete="off" placeholder="Alamat/Lokasi Jaminan"> </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-sm-4">Nilai Jaminan</label>
                                        <div class="col-sm-8"><input type="text" name="nilai_jaminan" class="form-control" id="nilai_jaminan" value="<?php echo $nilai_jaminan;?>"
										required="required" autocomplete="off" placeholder="Nilai Jaminan"> </div>
                                    </div>
							</div>
                        </div>
                    </div>
					<div class="panel panel-default">
                        <div class="panel-heading">
                            <h5 class="panel-title">
                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFour2" style="text-decoration:none; font-weight: bold">
                                    4. AKUN LOGIN
                                    <i class="fa fa-angle-down pull-right"></i>
                                </a>
                            </h5>
                        </div>
                        <div id="collapseFour2" class="panel-collapse collapse">
                            <div class="panel-body" style='background-color:#f8f8f8;'>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Username</label>
                                        <div class="col-sm-8"><input type="text" name="uname" class="form-control" id="uname" value="<?php echo $uname;?>"
										required="required" autocomplete="off" placeholder="Username"> </div>
                                    </div>
									<div class="form-group">
                                        <label class="control-label col-sm-4">Password</label>
                                        <div class="col-sm-8"><input type="text" name="pass" class="form-control" id="pass" value="<?php echo $pass;?>"
										required="required" autocomplete="off" placeholder="Password"> </div>
                                    </div>
							</div>
                        </div>
                    </div>
                </div>
									
									
</div> 

<div class="col-md-5 mt-n-md">
	<section class="widget" style="border: 1px solid #5d8fc2; margin-top:-50px;">
		<div class="widget-body clearfix">
			<div class="widget-top-overflow windget-padding-md clearfix bg-primary">
				<span class="h4 text-white"><i class="glyphicon glyphicon-th-large"></i> Simpanan
					<span class="pull-right">
						<button class="btn btn-xs btn-default" href="" data-toggle="modal" data-target="#myModalSimpananUmum" value="<?php echo $nik; ?>" id="MySimpananUmum"><span class="fs-mini">[+] Simp. Umum</span></button>
						<button class="btn btn-xs btn-default" href="" data-toggle="modal" data-target="#myModalSimpananDepo" value="<?php echo $nik; ?>" id="MySimpananDepo"><span class="fs-mini">[+] Simp. Deposito</span></button>
					</span>
				</span>
			</div>
		<div id="TampilSimpanan"></div>	
		</div>		
	</section>		
</div>
 
<div class="col-md-5 mt-n-md">
<section class="widget" style="background-color:#dddeee; min-height:750px;">
                    <div class="widget-body clearfix">
						<div class="widget-top-overflow windget-padding-md clearfix bg-primary">
                            <span class="h5 fw-bold text-white"><i class="glyphicon glyphicon-user"></i> <?php echo "$namadepan | $nik";?></span>
                        </div>
			
			
			<legend class="text-align-center">
			<span class="thumb-sm avatar img-user mt-sm text-align-center" style="width:200px;">
							<?php
										$foto=$r['foto'];
										if (empty($foto)) {
											echo "<img  src='images/avatar.png' alt='...'>";
											}else{
											echo "<img  alt='' src='$foto'>";
											}
										?>
                        </span>
			<br>&nbsp;</legend>
			<div id="konfirmasi"></div>
			<button class="btn btn-primary btn-rounded mb-sm ml-xs width-100" id="SimpanPenduduk"><h3><i class="fa fa-floppy-o"></i></h3>S I M P A N<br>D A T A</button>
	<?php if($_SESSION['unt']==1) { ?>		
			<button class="btn btn-default btn-rounded mb-sm ml-xs width-100" data-toggle="collapse" data-parent="#accordionIndividu" href="#collapseIndividu" value="<?php echo $nik; ?>" id="ProposalIndividu"><h3><i class="glyphicon glyphicon-user"></i></h3>[+] Pinjaman<BR>Individu</button>
			<button class="btn btn-default btn-rounded mb-sm ml-xs width-100" data-toggle="collapse" data-parent="#accordionKelompok" href="#collapseKelompok" value="<?php echo $nik; ?>" id="ProposalKelompok"><h3><i class="fa fa-group"></i></h3>[+] Pinjaman<BR>Kelompok</button>
	<?php }else{ ?>
			<button class="btn btn-default btn-rounded mb-sm ml-xs width-100" data-toggle="collapse" data-parent="#accordionPeternakan" href="#collapsePeternakan" value="<?php echo $nik; ?>" id="ProposalPeternakan"><h3><i class="fa fa-pied-piper-alt"></i></h3>[+] Proposal<BR>P 4</button>
	<?php } ?>
			<button class="btn btn-default btn-rounded mb-sm ml-xs width-100" href="javascript:;" onclick="MM_openBrWindow('modul/pinjaman/cp/KAngg.php?rcp=<?php echo $nik; ?>','page','toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=800,height=1200,left=180,top=0,titlebar=0' )"><h3><i class="glyphicon glyphicon-print"></i></h3>Cetak Kartu<BR>Member</button>
			<button class="btn btn-default btn-rounded mb-sm ml-xs width-100" data-toggle="collapse" data-parent="#accordionMutasi" href="#collapseMutasi" value="<?php echo $nik; ?>" id="MutasiAntarKec"><h3><i class="fa fa-refresh"></i></h3> Mutasi Antar<BR>Kecamatan</button>
			<button class="btn btn-default btn-rounded mb-sm ml-xs width-100" data-toggle="collapse" data-parent="#accordionBlackList" href="#collapseBlackList" value="<?php echo $nik; ?>" id="MutasiAntarKec"><h3><i class="glyphicon glyphicon-remove-sign"></i></h3>Black List<BR>N I K</button>
		
			
							
				<!-- BLACK LIST -->
			<div class="panel-group mb-lg" id="accordionBlackList" data-toggle="collapse">
								<div class="panel panel-default">
									<div id="collapseBlackList" class="panel-collapse collapse">
										<div class="panel-body">
											<?php
												
														echo "
														<div class='alert alert-danger mt animated fadeInDown'>
															<button type='button' class='close' data-dismiss='alert' aria-hidden='true'><i class='fa fa-times-circle'></i></button>
															<span class='create-server-name'></span><i class='fa fa-warning'></i> <strong>Perhatian</strong> 
															<br>Apakah Yakin anda akan melakukan Black List?
															<button type='button' class='btn btn-danger' id='BlackList'>Ya</button>
														</div>
														";
												
					?>
										</div>
									</div>
								</div>
							</div>

			
	
</div>		
</section>		
					
</div>

<div class="col-md-5 mt-n-md">
	<section class="widget" style="border: 1px solid #5d8fc2;">
		<div class="widget-body clearfix">
			<div class="widget-top-overflow windget-padding-md clearfix bg-primary">
				<span class="h4 text-white"><i class="glyphicon glyphicon-th-large"></i> Simpanan
					<span class="pull-right">
						<button class="btn btn-xs btn-default" href="" data-toggle="modal" data-target="#myModalSimpananUmum" value="<?php echo $nik; ?>" id="MySimpananUmum"><span class="fs-mini">[+] Simp. Umum</span></button>
						<button class="btn btn-xs btn-default" href="" data-toggle="modal" data-target="#myModalSimpananDepo" value="<?php echo $nik; ?>" id="MySimpananDepo"><span class="fs-mini">[+] Simp. Deposito</span></button>
					</span>
				</span>
			</div>
		<div id="TampilSimpanan"></div>	
		</div>		
	</section>		
</div>



<!-- MODAL TAMBAH SIMPANAN UMUM -->
						<div class="modal fade" id="myModalSimpananUmum" tabindex="" role="dialog" aria-labelledby="LabelSimpananUmum" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                        <h4 class="modal-title" id="LabelSimpananUmum">
											<i class='glyphicon glyphicon-user'></i> Formulir Pembukaan Simpanan Umum
											<ul class="tags pull-right">
												<li><a href="#" type="button" data-dismiss="modal" aria-hidden="true" > <span class="fs-mini"><i class="glyphicon glyphicon-remove"></i></span></a></li>
											</ul>
										</h4>
                                    </div>
                                    <div class="modal-body">
										<div id="FormSimpananUmum"></div>
									</div>
                                </div>
                            </div>
                        </div>	
						
						
<!-- MODAL TAMBAH SIMPANAN DEPOSITO -->
						<div class="modal fade" id="myModalSimpananDepo" tabindex="" role="dialog" aria-labelledby="LabelSimpananDepo" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary">
                                        <h4 class="modal-title" id="LabelSimpananDepo">
											<i class='glyphicon glyphicon-user'></i> Formulir Pembukaan Simpanan Deposito
											<ul class="tags pull-right">
												<li><a href="#" type="button" data-dismiss="modal" aria-hidden="true" > <span class="fs-mini"><i class="glyphicon glyphicon-remove"></i></span></a></li>
											</ul>
										</h4>
                                    </div>
                                    <div class="modal-body">
										<div id="FormSimpananDepo"></div>
									</div>
                                </div>
                            </div>
                        </div>	
						
