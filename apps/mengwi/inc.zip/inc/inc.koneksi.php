<?php

$server = "localhost"; 
$username = "abtmajumapan_upk_apps";  
$password = "abtmajumapan_upk_apps"; //upkbaru
$database = "abtmajumapan_upk_apps";

$konek = mysql_connect($server, $username, $password) or die ("Gagal konek ke server MySQL" .mysql_error());
$bukadb = mysql_select_db($database) or die ("Gagal membuka database" .mysql_error());

date_default_timezone_set('Asia/Jakarta');
?>